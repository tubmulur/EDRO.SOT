<!--/\ © A.A.CheckMaRev tubmulur@yandex.ru
  <  **>
    Jl-->
<?php
//How does it works (require):
//1. load VectorKIIM Class file (require/home/...VectorKIIM);
//1.1.
//2. Compile it into object (our name of compiled object is objKIIM);
//3. Call objectKIIM, after start method;
//4. Call objectKIIM, before end of method;
//
//$objKIIM=KIIM::objStart($objKIIM,
//	array(
//		'_strClass'		=>__CLASS__, 
//		'_strMethod'		=>__FUNCTION__,
//		'_strMessage'		=> 'Optional',
//		'_strVectorPoint'	=> 'Optional',
//	));
// _strClass		=>__CLASS__,
// _strMethod		=>__FUNCTION__,
// _strMessage		=> Message you will see in debug mode, after Class/Method/essage,
// _strVectorPoint	=>Avaliable variants: Start/Finish;

/*
$objKIIM=KIIM::objStart($objKIIM, array(
	'_strClass'		=>'Index',
	'_strMethod'		=>'System loader',
	'_strMessage'		=>'LoadLibs',
	'_strVectorPoint'	=>'Start',
	));
*/
// License of usage VectorKIIM. I'm small code creator from Admiralteyskiy paradise district in SPB, Russia. I spand too mutch time to make my job,
// so i don't understend, what i must write to feel myself safe in terms of licensing. Please help me if you can. Thank you.
//
class KIIM
	{
	private $floatStartMicrotime=0.00;
	private $intStep=0;
	private $intDefaultTempo	=10;

	private $arrVector=array(
		array(
			// 'intStep'=>0,
			'strAction'=>'',
			'arrTimers'=>array(
				'floatStepStart'	=>0.00,
				'floatStepFinish'	=>0.00,
				),
			'arrPosition'=>array(
				'strClass'		=>'',
				'strMethod'		=>'',
				'strMessage'		=>'',
				'strVectorPoint'	=>'',
				'intShowTempo'		=>'',
				),
			'strReport'=>'',
			)
		);
	public function __construct(
			$_arrPosition=array(
				'_strClass'		=>'',
				'_strMethod'		=>'',
				'_strMessage'		=>'',
				'_strVectorPoint'	=>'',
				'_intShowTempo'		=>'',
				)
			)
		{
		$this->arrVector[]['arrPosition']=$this->arrPrepare($_arrPosition);
		if(empty($this->floatStartMicrotime))
			{
			$this->floatStartMicrotime	=mktime(true);
			}
		$this->_Start($_arrPosition);
		}
	public function _Start($_arrPosition)
		{
		$arrPosition = $this->arrPrepare($_arrPosition);
		unset($_arrPosition);
		$this->intStep++;
		$this->arrVector[$this->intStep]['arrTimers']=array(
				'floatStepStart'=>mktime(true),
				'floatStepFinish'=>0.00,
				);
		$this->arrVector[$this->intStep]['arrPosition']=$arrPosition;
		$this->_Report('Begin');
		}
	public function _Finish($_arrPosition)
		{
		$arrPosition = $_arrPosition;
		unset($_arrPosition);
		if($this->arrVector[$this->intStep]['arrPosition']['strClass']		!=$arrPosition['strClass'])
			{
			$this->_Error('Error:begin->end strClass is not equal');
			}
		if($this->arrVector[$this->intStep]['arrPosition']['strMethod']		!=$arrPosition['strMethod'])
			{
			echo $this->_Error('Error:begin->end strMethod is not equal');
			}
		$this->arrVector[$this->intStep]['arrPosition']['strMessage']		=$arrPosition['strMessage'];
		$this->arrVector[$this->intStep]['arrPosition']['strVectorPoint']	=$arrPosition['strVectorPoint'];
		
		$this->arrVector[$this->intStep]['arrPosition']['intShowTempo']		=$arrPosition['intShowTempo'];
		$this->arrVector[$this->intStep]['arrTimers']['floatStepFinish']	=mktime(true);
		$this->_Report('End');
		    
		unset($this->arrVector[$this->intStep]);
		$this->intStep--;
		}

	private function _Report($_strAction)
		{
		switch($_strAction)
			{
			case 'Begin':
				$this->arrVector[$this->intStep]['strReport']='
				<KIIMStep class="block" style="border:1px solid #aaa;margin-left:10px">';
					//$this->arrVector[$this->intStep]['strReport'].=$this->intStep.'.===\\'.$this->intStep.'/===============================\\'.$this->intStep.'/==='."<br/>";  //'
					$this->arrVector[$this->intStep]['strReport'].=
						'<position class="block" style="background-color:#000;color:#fff;">'.
							'<whiteFlag class="block left" style="background-color:#fff;color:#000;">'.
								    $this->intStep.
							'V </whiteFlag>'.
							'<EventInfo class="block left">'.
								'<EventClass class="block left" style="background-color: rgb(8, 75, 117);">'.
									$this->arrVector[$this->intStep]['arrPosition']['strClass'].
								'</EventClass>'.
								'<EventFunction class="block left" style="background-color: rgb(14, 149, 0);">'.
									$this->arrVector[$this->intStep]['arrPosition']['strMethod'].	
									$this->arrVector[$this->intStep]['arrPosition']['strMessage'].
								'</EventFunction>'.
							'</EventInfo>'.
						'</position>';
			break;
			case 'End':
				//print_r($this->arrVector[$this->intStep]['arrPosition']);
				$this->arrVector[$this->intStep]['strReport']='
					
					<position class="block" style="background-color:#222;color:#fff;">'.
						'<whiteFlag class="block left" style="background-color:#fff;color:#000;">'.$this->intStep.'/\</whiteFlag>'.
						/* '.'.$this->arrVector[$this->intStep]['arrPosition']['strClass'].
						'/'.$this->arrVector[$this->intStep]['arrPosition']['strMethod'].
						'/'.$this->arrVector[$this->intStep]['arrPosition']['strMessage']. */
						''.
						$this->intRoundMicrotime(($this->arrVector[$this->intStep]['arrTimers']['floatStepFinish']-$this->arrVector[$this->intStep]['arrTimers']['floatStepStart'])).
						'sec. : '.
						$this->intRoundMicrotime(($this->arrVector[$this->intStep]['arrTimers']['floatStepFinish']-$this->floatStartMicrotime)).
						'sec.'.
					'</position>';
				
			$this->arrVector[$this->intStep]['strReport'].='</KIIMStep>';
			break;
			}
		?>
		<script charset="utf-8">
			var objKIIMDebug		=document.getElementById('KIIMDebug');
			var KIIMdebugProcessing		=document.getElementById('KIIMdebugProcessing');
			var KIIMdebugProcessFinished	=document.getElementById('KIIMdebugProcessFinished');
			var strKIIMScreen		=document.getElementById('KIIMDebug').innerHTML;
		<?php
		if($this->arrVector[$this->intStep]['arrPosition']['strVectorPoint']=='Start')
			{
			$this->arrVector[$this->intStep]['strReport'].='
				<KIIMStart style="display:block;background-color:yellow;color:#000;">
					Process 
					'.
					$this->arrVector[$this->intStep]['arrPosition']['strVectorPoint'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strClass'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strstrMethod'].
					'VectorKIIM
				</KIIMStart>';
			}
		elseif($this->arrVector[$this->intStep]['arrPosition']['strVectorPoint']=='Finish')
			{
			$this->arrVector[$this->intStep]['strReport'].='
				<KIIMFinish style="display:block;background-color:green;color:#fff;">
					Process->'.
					$this->arrVector[$this->intStep]['arrPosition']['strVectorPoint'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strClass'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strMethod'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strMessage'].
					'<-
				</KIIMFinish>';
			?>
			setTimeout(function()
				{
				console.log("<?=base64_encode($this->arrVector[$this->intStep]['arrPosition']['strClass'])?>");
				var strStartFinish='<unit style="display:block;float:left;margin-left:5px;margin-top:1px;background-color:#aaa;">'+b64dcd("<?=base64_encode($this->arrVector[$this->intStep]['arrPosition']['strClass'])?>")+'</unit>';
				var strCurrentStartFinishList=KIIMdebugProcessFinished.innerHTML;
				KIIMdebugProcessFinished.innerHTML=strStartFinish+strCurrentStartFinishList;
				},(K*50));
			<?php
			}
		else
			{
			$this->arrVector[$this->intStep]['strReport'].='
				<KIIMStart style="display:block;">
					Process->'.
					$this->arrVector[$this->intStep]['arrPosition']['strVectorPoint'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strClass'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strMethod'].
					' '.
					$this->arrVector[$this->intStep]['arrPosition']['strMessage'].
					'<-
				</KIIMStart>';
			?>
			setTimeout(function()
				{
				KIIMdebugProcessing.innerHTML=b64dcd("<?=base64_encode($this->arrVector[$this->intStep]['arrPosition']['strClass'])?>");
				},(K*50));
			<?php
			}
		$this->arrVector[$this->intStep]['strReport'];
			?>
			setTimeout(function()
				{
				objKIIMDebug.innerHTML		=b64dcd("<?=base64_encode($this->arrVector[$this->intStep]['strReport'])?>");
				var intKIIMDebugStep		=parseInt(document.getElementById('intKIIMDebugStep').innerHTML);
				document.getElementById('intKIIMDebugStep').innerHTML=(intKIIMDebugStep+1);
				},(K*50));
			K++;
		</script>
		<?php
		//echo $this->arrVector[$this->intStep]['arrPosition']['intShowTempo'];
		//file_put_contents('/home/cloudrepublic.ru/tmp/report.txt', $this->arrVector[$this->intStep]['strReport']);
		}
	private function intRoundMicrotime($_floatMicrotime)
		{
		if($_floatMicrotime<0)
			{
			$this->_Error('Time is <0');
			}
		if($_floatMicrotime<0.0001)
			{
			return 0;
			}
		else
			{
			return $_floatMicrotime;
			}
		}
	private function arrPrepare($_arrPosition)
		{
		//$arrPosition['strClass']		= preg_replace('[^A-Za-z]', '', $_arrPosition['_strClass']);
		//$arrPosition['strMethod']	 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMethod']);
		//$arrPosition['strMessage']		= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMessage']);
		//$arrPosition['strVectorPoint'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strVectorPoint']);
		$arrPosition=$_arrPosition;
		return $arrPosition;
		}
	private function _Error($_strMessage)
		{
		print_r($this);
		echo '<Error class="block" style="color:red;">'.$_strMessage."</Error>";
		exit(0);
		}

	public static function objStart($_objKIIM, $_arrPosition=array(
								'_strClass'		=>'', 
								'_strMethod'		=>'', 
								'_strMessage'		=>'',
								'_strVectorPoint'	=>'',
								))
		{
		$objKIIM	=$_objKIIM;
			   unset($_objKIIM);
		$arrPosition['strClass']   	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strClass']);
		$arrPosition['strMethod']   	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMethod']);
		$arrPosition['strMessage'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMessage']);
		$arrPosition['strVectorPoint'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strVectorPoint']);
		$arrPosition['intShowTempo'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_intShowTempo']);
		unset($_arrPosition);
		if(is_object($objKIIM))
			{
			$objKIIM->_Start($arrPosition);
			}
		else
			{
			$objKIIM=new KIIM($arrPosition);
			}
		return $objKIIM;
		}
	public static function objFinish($_objKIIM, $_arrPosition=array(
								'_strClass'		=>'', 
								'_strMethod'		=>'', 
								'_strMessage'		=>'',
								'_strVectorPoint'	=>'',
								))
		{
		//echo'123';
		
		$objKIIM	=$_objKIIM;
			   unset($_objKIIM);
		$arrPosition['strClass']   	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strClass']);
		$arrPosition['strMethod']   	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMethod']);
		$arrPosition['strMessage'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strMessage']);
		$arrPosition['strVectorPoint'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_strVectorPoint']);
		$arrPosition['intShowTempo'] 	= preg_replace('[^A-Za-z]', '', $_arrPosition['_intShowTempo']);
		unset($_arrPosition);
		if(is_object($objKIIM))
			{
			$objKIIM->_Finish($arrPosition);
			}
		else
			{
			Report::strError($_objKIIM, array(
				'_strClass'		=>__CLASS__,
				'_strFunction'		=>__FUNCTION__,
				'_strMessage'		=>'Error: Kiim vector is lost continiuty',
			//	'_objBeforeCrash'	=> $this,
				));
			}
		return $objKIIM;
		}
	}
?>