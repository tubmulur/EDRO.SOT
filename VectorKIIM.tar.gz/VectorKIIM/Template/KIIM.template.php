<!--/\ © A.A.CheckMaRev tubmulur@yandex.ru
  <  **>
    Jl-->
<?php
$strKIIMWindow='
	<KIIMDebug
		
		class=""
		style="
			height:50vh;
			width:98vw;
			border:1px solid #000;
			background-color:#fff;
			display:block;
			overflow: hidden;
			"
			>
			<header>HiFiIntelligentClub.ru: ВекторКИМа</header>
			<DebugInfo
				id="KIIMDebug"
				style="
					height:79px; 
					width:98vw;
					background-color:#fff;
					display:block;
					overflow: scroll;
				"
				>
			</DebugInfo>
			<DebugStep
				
				style="
					background-color:#fff;
					display:block;
					overflow: hidden;
				"
				>
				<intCurrentStep
					id="intKIIMDebugStep"
					style="
						display:block;
						float:left;
						"
					>
					0
				</intCurrentStep>
					
				<intCurrentStepDiv
					style="
						display:block;
						float:left;
						"
					>
					_of_
				</intCurrentStepDiv>	
				<intCurrentStepAll
					style="
						display:block;
						"
					>
					0
				<intCurrentStepAll>
			</intDebugStep>
			<DebugProcessing
				style="
					width:100%;
					background-color:#fff;
					display:block;
					overflow: hidden;
				"
				>
				<title
					style="
						display:block;
						float:left;
						"
					>
					Processing:
				</title>
				<textData
					id="KIIMdebugProcessing"
					style="
						display:block;
						float:left;
						"
					>
					.....
				</textData>
			</DebugProcess>
			<DebugProcessFinished
				style="
					width:100%;
					height:20vh;
					background-color:#fff;
					display:block;
					overflow-y: scroll;
				"
				>
				<title
					style="
						display:block;
						float:left;
						"
					>
					Finished:
				</title>
				<textData
					id="KIIMdebugProcessFinished"
					style="
						display:block;
						float:left;
						"
					>
					.....
				</textData>
			</DebugProcessFinished>
	</KIIMDebug>';
?>