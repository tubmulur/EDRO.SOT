<!--/\ © A.A.CheckMaRev tubmulur@yandex.ru
  <  **>
    Jl-->
<?php
$objKIIM=KIIM::objStart($objKIIM, array(
	'_strClass'		=>'0',
	'_strMethod'		=>'0',
	'_strMessage'		=>'KIIM activated',
	'_strVectorPoint'	=>'Start',
	));
?>
