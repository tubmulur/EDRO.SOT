<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
//$_arrData=array('strDir'=>'dir', 'strFile'=>'file');
/*
$arrFile=array(
	'arr@strFile'=>array(
		''
	)
)
$_strAction= default/html/json/array;
$arr= array('arr@strType'	=>array(
			arr@strLang	=>array(
				'strName'=>'',
				'strHtml'=>'',
				)
			),
		);

$arrType=array(	'dir'	=>array(
			'RU'=>array(
				'strName'=>'',
				'strHtml'=>'',
				),
			),
		'dirUp'	=>array(
			'RU'=>array(
				'strName'=>'',
				'strHtml'=>'',
				),
			),
		'file'	=>array(
			'RU'=>array(
				'strName'=>'',
				'strHtml'=>'',
				),
			),
		'song'	=>array(
			'RU'=>array(
				'strName'=>'',
				'strHtml'=>'',
				),
			),
		);
*/
class ConstructFile extends Reality
	{
	public $strName		='';
	public $strDir		='';

	public $arr	=array(
		'arrType'=>array(
			'strType'=>'',
			),
		'arrInfo'=>array(
			),
		);
	public $strHTML	='';


	public function __construct($_objKIIM, $_strAction='default', $_arrData=array())
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$this->strDir		= $_arrData['_strDir'];

		$this->strName 		= $_arrData['_strName'];

		$objType		=new FileType($_objKIIM, 'default', $_arrData);
		$this->arr['arrType']	=$objType->arr;
		$objInfo		=new FileInfo($_objKIIM, 'default', $_arrData);
		$this->arr['arrInfo']	=$objInfo->arr;

		parent::__construct($objKIIM, $this->strDir.$this->strName);
		
		//print_r($this);
		//exit(0);
		//$objBlock=new DynaBlock($_objKIIM, $this);
		$this->strHTML=$objBlock->strHTML;

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	}
?>