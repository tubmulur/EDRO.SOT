<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
//$_arrData=array('strDir'=>'dir', 'strFile'=>'file');
class ReadFileSetup extends Reality
	{
	protected 	$arrSetup;
	private 	$_arrSetup;
	public function __construct($_objKIIM, $_strAction='default', $_arrData=array())
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		//print_r($this->strSetupFile);

		$linkFile=fopen($this->strSetupFile, 'r');
		$strAbout=fread($linkFile, 4096);
		$this->arrSetup=json_decode($strAbout);
		fclose($linkFile);
		
		parent::__construct($objKIIM);
		
		echo $this->strReality;
		//$this->_arrSetup < $this->strReality; [!]
		
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	}
?>