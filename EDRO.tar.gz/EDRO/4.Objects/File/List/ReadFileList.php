<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
class ReadFileList
	{
	public function __construct($_objKIIM)
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>'$this->strEnterDir='.$this->strEnterDir));

		$this->arr 	=array();
		$arrFile	=scandir($this->strEnterDir);
		if(empty($this->arr))
			{
			//Report::_Error($objKIIM, array(
			//		'_strClass'	=>__CLASS__,
			//		'_strFunction'	=>__FUNCTION__,
			//		'_strMessage'	=>'Error: $this->arr is empty',
			//		) 
			//	);
			}
		foreach($arrFile as $intI=>$strFile)
			{
			if($strFile!='.'&&$strFile!='..')
				{
				$arr[]=$strFile;
				}
			}
		$this->arr	=$arr;

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>'$this->strEnterDir='.$this->strEnterDir));
		}
	}

?>