<?php
class SetFilePaths extends ReadFileSetup
	{
	protected $strName;
	protected $strDir;
	protected $strSetupFile;
	protected $arrSetup;
	public function __construct($_objKIIM)
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$this->strFullPath	= $this->strDir.$this->strName;

		if(is_file($this->strFullPath))
			{
			//!echo $this->strFullPath.' is file';
			}
		elseif(is_dir($this->strFullPath))
			{
			//!echo $this->strFullPath.' is dir';
			}
		else
			{
			echo $this->strFullPath.' not exist';
			echo '<br/>';
			}

		$this->strSetupFile	= $this->strFullPath.'/.setup.json';
		
		if(is_file($this->strSetupFile))
			{
			//!echo $this->strSetupFile.'=File';
			//!echo '<br/>';
			}
		else
			{
			echo $this->strSetupFile.'No setup file.';
			echo '<br/>';
			}

		//print_r($this);

		parent::__construct($objKIIM);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	}
?>