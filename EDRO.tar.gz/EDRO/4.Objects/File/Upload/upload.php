<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
//////   /\ RCe	[E] Event
   //  <  **> 	[D] Design/Destination/Doing
 //     Jl   	[R] Reality/Role
////// 2020	[O] Objects
/*array(	
	'CopyrightSign'=>array(
		'strType'=>'dir/',
		);
);*/
class FileList extends Reality
	{
	private $strEnterDir	='';
	private $strSort 	='';
	private $bIsUpperDir	=false;
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
        	//$strSubDir='/'.preg_replace('[^A-Za-z\.0-9]', '', $_strSubDir);
        	//unset($_strSubDir);
		
		$this->strEnterDir 	=$_strEnterDir;
		$this->strSort		=$_strSort;
		$this->bIsUpperDir	=false;

		if(empty($this->strEnterDir))
			{
			$this->strEnterDir	=$this->strBaseDir;
			$this->bIsUpperDir	=true;
			}
		$this->arr=$this->arrGetDir($objKIIM);
		$this->arr=$this->arrSort($objKIIM);
		//print_r($this);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	<?php
	if(!empty($_FILES))
		{
		print_r($_FILES);
		$strPathToMoveFile='/home/cloudrepublic.ru/tmp/'.$_FILES['record']['name'];
		if(move_uploaded_file($_FILES['record']['tmp_name'], $strPathToMoveFile))
			{
			echo 'ok<br/>';
			}
		}
	if(!empty($_POST))
		{
		print_r($_POST);
		}
	?>
	<html>
		<head>
		</head>
		<body>
			<form method="post" action="/upload.php" enctype="multipart/form-data">
    				<input type="file" name="record" />
				<input type="submit" value="submit"/>
			</form>
		</body>
	</html>