<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
//////   /\ RCe	[E] Event
   //  <  **> 	[D] Design/Destination/Doing
 //     Jl   	[R] Reality/Role
////// 2020	[O] Objects
/*array(	
	'CopyrightSign'=>array(
		'strType'=>'dir/',
		);
);*/
class UploadForm extends Reality
	{
	public	$arr	=array();
	private $strHtml='';
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		//
		$this->strHtml=$this->strHtml($objKIIM);
		//
		//
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function strHtml($_objKIIM)
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$str='<form method="post" action="/upload.php" enctype="multipart/form-data">
				<input type="file" name="record" />
				<input type="submit" value="submit"/>
		</form>';

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $str;
		}
	public static function html($_objKIIM, $_arrData=array(), $strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		$html='';

		$objUpload=new UploadForm($objKIIM, $_arrData, $_strAction);
		$objUpload->strHtml;

		//$html=DynaBlock::html($objKIIM, $this);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $objUpload->strHtml;
		}
	}
?>