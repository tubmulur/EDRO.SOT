<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
//////   /\ RCe	[E] Event
   //  <  **> 	[D] Design/Destination/Doing
 //     Jl   	[R] Reality/Role
////// 2020	[O] Objects
/*array(	
	'CopyrightSign'=>array(
		'strType'=>'dir/',
		);
);*/
class Upload extends Reality
	{
	public	$arr	=array();
	private $strHtml='';
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		parent::__construct($objKIIM);

		//echo $_strAction;
		if(!empty($_FILES))
			{
			print_r($_FILES);
			$strPathToMoveFile='/home/cloudrepublic.ru/tmp/'.$_FILES['record']['name'];
			if(move_uploaded_file($_FILES['record']['tmp_name'], $strPathToMoveFile))
				{
				echo 'ok<br/>';
				}
			}
		if(!empty($_POST))
			{
			print_r($_POST);
			}

		switch($_strAction)
			{
			case 'default':
				$this->strHtml=UploadForm::html($objKIIM);
			break;
			case 'showForm':
				
			break;
			case 'Process':
			break;
			}
		$this->strHtml;

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	public static function html($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		$html='';
		$objUpload=new Upload($objKIIM, $_arrData, $_strAction);
		
		//$html=DynaBlock::html($objKIIM, $this);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $html;
		}
	public static function _Html($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;
        	unset($_objKIIM);
        	$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		
		$html='';
		$objUpload=new Upload($objKIIM, $_arrData, $_strAction);
		$html.=$objUpload->strHtml;
		echo $html;

		//$html=DynaBlock::html($objKIIM, $this);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $html;
		}
	}
?>