<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
$arrFileTypes=array(
	'dir'=>array(
		'RU'=>array(
			'icon'=>'i',
			'name'=>'Каталог',
			'shortName'=>'Каталог',
		),
		'EN'=>array(
			'icon'=>'i',
			'name'=>'Directory',
			'shortName'=>'Dir',
		)
	)
);
?>