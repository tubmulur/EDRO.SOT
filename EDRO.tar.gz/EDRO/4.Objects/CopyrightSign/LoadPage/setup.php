<?php
//Event: Load main page, pushed url="/"
$arrLoadPageData=array(
	'strPage'=>'',
	);
?>