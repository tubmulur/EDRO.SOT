<?php
/*© A.A.CheckMaRev assminog@gmail.com*/
//////   /\ RCe	[E] Event
   //  <  **> 	[D] Design/Destination/Doing
 //     Jl   	[R] Reality/Role
////// 2020	[O] Objects

class Object 
	{
	public function __construct($_objKIIM)
		{
		}
	}
?>