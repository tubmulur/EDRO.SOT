<!---
© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru
-->
<?php
$strDynascreenStyle="
<style>
	/*RCe father*/
	body		{font-family:sans-serif;}
	.feetScreen	{width:100vw;height:93.5vh;}
	
	/*RCe matrix*/
	.matrixTop	{position:fixed;top:0px;}
	.matrixLeft	{position:fixed;top:40px;left:0;}
	.matrixRight	{position:fixed;top:40px;right:0;}
	.matrixBottom	{position:fixed;bottom:0px;}
	/*//RCe matrix*/

	/*RCe player*/
	/*/RCe.Author.table*/
	audioTrack {border-top: 1px solid #aaa;border-bottom: 1px solid #aaa;}
	audioTrack:hover {background-color:#ccc;}
	/*//RCe player*/

	/*RCe base*/
	window 		{}
	.block		{display:block;overflow:hidden;}
	.rel		{position:relative;}
	.abs		{position:absolute;}
	.fixed		{position:fixed;}
	.left		{float:left;}
	.right		{float:right;}
	.scrollerY	{overflow-x:hidden;overflow-y:scroll;}
	.scrollerGlide	{-webkit-overflow-scrolling:touch;}
	.border		{border:1px solid #aaa}
	.loading overlay{display:block;}
	.loaded overlay {opacity:0!important;visibility:hidden!important;transition: visibility 0s linear 0.9s, opacity 0.9s ease-in-out;}
	 /*//RCe base*/          

	/*RCe layers*/
	.layer_1 {z-index:1;}
	.layer_1_1{z-index:2;}
	.layer_1_2{z-index:3;}
	.layer_1_3{z-index:4;}
	.layer_1_4{z-index:5;}

	.layer_2 {z-index:20;}
	.layer_2_1{z-index:21;}
	.layer_2_2{z-index:22;}
	.layer_2_3{z-index:23;}
	.layer_2_4{z-index:24;}

	.layer_3 {z-index:30;}
	.layer_3_1{z-index:31;}
	.layer_3_2{z-index:32;}
	.layer_3_3{z-index:33;}
	.layer_3_4{z-index:34;}

	.layer_4 {z-index:40;}
	.layer_4_1{z-index:41;}
	.layer_4_2{z-index:42;}
	.layer_4_3{z-index:43;}
	.layer_4_4{z-index:44;}
	/*//RCe layers*/

	/*//RCe touch fx*/
	.touch-active:hover{border-color:green!important;}
	.touch-active:active{border-color:red!important;}
	.no-select{-webkit-user-select:none;-ms-user-select:none;user-select:none;}
	/*//RCe touch fx*/

	/*// RCe.Objects */
	article{padding: 0 0 0 0;}
	/*// RCe.Objects */

	/*// RCe.Mobile compatibility */
	@media screen and (max-width:1200px)
		{
		dynablock a
			{
			width:48%;
			height: 100px;	
			margin:1px;
			}
		dynablock overlay
			{
			line-height:100px;
			}
		}
	@media screen and (min-width:1200px)
		{
		dynablock a
			{
			width: 24%;
			height: 200px;
			margin:3px;
			}
		dynablock overlay
			{
			line-height:200px;
			}
		}
	/*// RCe.Mobile compatibility */

	/*// RCe.Animation */
	@keyframes hideElement
		{
		0% {
		    opacity:1;
		    }
		100% {
		    opacity:0;
		    
		    }
		}
	/*// RCe.Animation */

</style>
";
?>