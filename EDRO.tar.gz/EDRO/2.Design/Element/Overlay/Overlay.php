<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
class Overlay
	{
	private $arr;
	private $html;
	public function __construct($_objKIIM, $_arrData=array(
							'_strTitle'=>'Test',
							'_strDescription'=>'Test description', 
							'_strCopyrightInfo'=>'....Comming soon',
							'_strLogo'=>'/image.png'
							)
				    )
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		$this->arr=$_arrData;
		$this->html='
		<overlay
			class="block abs layer_2"
			style="
				visibility:visible;
				opacity:1;
				width: 100%;
				height: 100%;
				text-align: center;
				background-color: rgb(38, 38, 38);
				color: rgb(161, 161, 161);
				"
			>
			Loading. Please wait.
			</overlay>';
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		//print_r($this);
		}
	public static function html($_objKIIM, $_strData)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$objOverlay=new Overlay($objKIIM);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $objOverlay->html;
		}
	}
?>