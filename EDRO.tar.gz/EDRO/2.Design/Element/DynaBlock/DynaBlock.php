<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
//////
   //   /\ RCe
  //  <  **> 
 //     Jl
//////
class DynaBlock
	{
	private $arr;
	private $strHRML;
	private $strLogo;
	private $strName;
	private $strAudio;
	public function __construct($_objKIIM, $_objData)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		print_r($_objData->arr['arrInfo']['arrReality']);
		$objInfo	=$_objData->objInfo;
		$arrObjInfo	=$objInfo->arr['RU'];
		$this->strLogo	=$arrObjInfo->strLogo;
		$this->strAudio	=$arrObjInfo->strAudio;
		$this->strName	=$_objData->strName;
		unset($_objData);
		//$this->arr	=$_arrData;
		$this->strHTML	='
		<a
			href="'.
				$this->strName.
				'"
			class="block left"
			onclick="console.log(\''.$this->strName.'\')"
			style="
				text-decoration: none;
				border: 1px solid rgb(197, 195, 195);
				background-color: rgba(249, 249, 249, 0.89);
				"
			>
			<dynaBlock
				class="block rel layer_1_1 loading"
				style="
					width:100%;
					height:100%;
					"
				>
				'.
				HficWorkForRespect::html($objKIIM, $this->arr['_strCopyrightInfo']).
				''.
				Shader::html($objKIIM, $this->strLogo).
				''.
				Player::html($objKIIM, $this->strAudio).
				''.
				Overlay::html($objKIIM, 'Loading. Please wait.').
				'
				<description
					class="block rel layer_1_4"
					>'.
					$this->arr['_strDescription'].
				'</description>
				<header
					class="block rel layer_1_4"
					style="
						background-color: rgba(0, 0, 0, 0.9);
						color: rgb(255, 255, 255);
						"
					>
					'.
					$this->strName.
				'</header>
				
				<!-- <marquee>Сообщения Сообщения Сообщения</marquee> -->
			</dynaBlock>
		</a>';
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		//print_r($this);
		}
	public static function html($_objKIIM, $_objData)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		//$arrData['_strName']=$_objData->strName;
		$objDynaBlock=new DynaBlock($objKIIM, $_objData);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		return $objDynaBlock->html;
		}
	}
?>