<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
class Shader
	{
	private $arr;
	private $html;
	private $strLogo;
	public function __construct($_objKIIM, $_strLogo)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$this->strLogo=$_strLogo;
		//$this->arr=$_arrData;
		$this->html='
		<shader
			class="block abs layer_1_3"
			style="
				width:100%;
				height:100%;
				background-color: rgba(252, 252, 252, 0.86);
				"
			>
			<img 
				src="'.$this->strLogo.'" 
				onload="setLoadedFlag(this);"
				style="width:100%""
				/>
		</shader>';
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		//print_r($this);
		}
	public static function html($_objKIIM, $_strLogo)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$objShader=new Shader($objKIIM, $_strLogo);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $objShader->html;
		}
	}
?>