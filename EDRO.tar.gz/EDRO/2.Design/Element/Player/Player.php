<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
class Player
	{
	private $arr;
	private $html;
	private $strAudio;
	public function __construct($_objKIIM, $_strAudio)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$this->strAudio=$_strAudio;
		//$this->arr=$_arrData;
		if(!empty($this->strAudio))
			{
			$this->html='
			<music
			    	class="block abs layer_1_3"
				style="
					width:100%;
					height:20%;
					background-color: rgba(252, 252, 252, 0.86);
					bottom:0px;
					"
				>
				<audio class="block" controls="">
					<source src="'.$this->strAudio.'"></source>
				</audio>
			</music>';
			}
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		//print_r($this);
		}
	public static function html($_objKIIM, $_strAudio)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));

		$objShader=new Player($objKIIM, $_strAudio);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		return $objShader->html;
		}
	}
?>