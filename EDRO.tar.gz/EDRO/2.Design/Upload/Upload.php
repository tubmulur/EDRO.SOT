<form method="post" action="/upload.php" enctype="multipart/form-data">
	<input type="file" name="record" />
	<input type="submit" value="submit"/>
</form>
