index.php:
1: loadKIIM
2: loadLoader
3: Loader->loadCore;
4: objShowFiles