© A.A.CheckMaRev assminog@gmail.com

/home/RCe.EDRO/documentation/Vocabulary/Accronimas/EDRO
___________________________________________________________________________________________________________________________________________

RCe.EDRO. The creator of the future.
___________________________________________________________________________________________________________________________________________
[E]							.										 [D]
A.1.What am I doing?					.A.2.Where am I (performing some)?
A.1.1.Looking for HFIC offer				.A.2.1.On the  page of CloudRepublic.RU
A.							.A
A.							.A.
A.							.A.
A.							.A.
							.
							.
							.
							.b.
							.B.
							.B.
							.B.
B.							.B..B.I am in a page setup
B.					     .........................
B.					 .......  ....    ......    .... 
B.					.......   .....	  .....	.  .. ... 
B.					..	  ..	. ..	. ..	..
B.Showing a list of content		..	  ..	. ..	. ..	..
..............................................	  ..	. ..	. ..	...................................................................
[R]					......	  ..	. .....   ..	..								 [O]
					..	  ..	. ..	. ..	..A.4.What am i using for doimg it?
					..	  ..	. ..	. ..	..A.4.1.Human vision.
A.3.Who am I?				......	  ......  ..    .   ..	. A.4.2.Human emotions.
					 .......  ....    ..	.   ....  A.4.3.Human estetic pereferences.
A.3.1.Looker, man who search the musical pleasure	..       . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . ... ... . .
A.							.A.
A.							.A.
A.							.A.
A.							.A.
A.							.. . . .  . . . . . . .  .. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
							.
							.
							.
B.							.
B.							.. . . . . . . . . . . . . . .. .. . . . . . . . . .. . . . . . .. . . . . . . . . . . .
B.							.B.
B.							.B.
B.							.B.RCe.Framework.Screen.Constructor.
B.DynaScreen setupper					.B.
                © A.A.Chekmarev, Russia, Saint-Petersbourg, Thu 12 march 2020, Lubimki.Ru@yandex.Ru.
___________________________________________________________________________________________________________________________________________
A.I am visiter						| B. I am  screen setupper.
1.array(						|array(
	'strEvent'	=>'sendShowCoolRequest',	|	'funcEvent'=>'EDRO(FileList,URL,PathToConstructor)'
	'strDesignPath'	=>'RefferedFromUrl',		|),
	'funcReality'	=>'FuncOpinonMaker',		|
	''		=>'',				|
)							|
							|
							|
							|
