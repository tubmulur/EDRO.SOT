<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
//////   /\ RCe:(b=bool;obj=object; 	[E] Event		     E={E} arrEvent	=array('Url1', 'Url2', ...);
   //  <  **> 	str=String;int=integer;	[D] Design/Destination/ToDo  D={D} arrDesign	=array('EventTemplate1', 'EventTemplate2', ...);
 //     Jl   	arr=array;		[R] Reality/Role/Permissions R={R} arrReality	=array('EventTemplate1Dj', 'EventTemplateMc', ...);
////// 2020	_Func=return nothing)	[O] Objects O={R:{E:{D}}}    
class Event extends EDRO
	{
	protected $strDir;
	protected $bDynamic=false;
	protected $bConsole=true;
	protected $bBrowser=false;
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		parent::__construct($objKIIM);
		$this->_IsDynamic($objKIIM);
		$this->_isConsoleOrBrowser($_objKIIM);

		$this->strDir=$this->strGetCurrentDir();

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function strGetCurrentDir()
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		$str=$_SERVER['REQUEST_URI'];

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		return $str;
		}
	private function _IsDynamic($_objKIIM)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		$b=false;
		if(isset($_POST['Dynamic']))
			{
			$b=true;
			}
		$this->bDynamic=$b;

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function _isConsoleOrBrowser($_objKIIM)
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		if(php_sapi_name()=='cli')
			{
			$this->bConsole=true;
			$this->bBrowser=false;
			}
		else
			{
			$this->bConsole=false;
			$this->bBrowser=true;
			}

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	}
?>