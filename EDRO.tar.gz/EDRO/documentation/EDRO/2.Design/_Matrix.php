Design constructor example:
class DesignAudioFile 
	//__construct()
		<audioFile>
			<audioTitleAuxDisplay>
				<aux>ObjectAudioName</aux><aux>ObjectAudioDescription</aux>
			</audioTitleAuxDisplay>
			<hficAudioWorkerRespectSystemDisplay>
				...
			</hficAudioWorkerRespectSystemDisplay>
			<playerControlsAux>
				<auxLine> <aux>ObjectRewindLeft</aux><aux>ObjectPlayButton</aux><aux>ObjectRewindRight</aux><aux></aux>	</auxLine>
				<auxLine> <aux>ObjectProgressBar</aux><aux></aux><aux></aux><aux></aux>			</auxLine>
			</playerControlsAux>
			<tagCorrectorAux>
				<auxLine> <aux>ObjInput::artist()</aux><aux>ObjInput::album()</aux><aux>ObjInput::addTagClass()</aux><aux></aux> </auxLine>
				<auxLine> <aux></aux><aux></aux><aux></aux><aux></aux> </auxLine>
			</tagCorrectorAux>
			<fileControlAux>
				<aux>ObjFileRename</aux><aux>ObjFileCompleteWithHQ</aux><aux>ObjFileCompleteWithVersions</aux><aux></aux>
				<aux>ObjFileCompleteWithRemixes</aux><aux></aux><aux></aux><aux></aux>
			</fileControlAux>
			<socialAux>
				<aux>ObjSendAudioTo::socialNet()</aux><aux>ObjSendAudioTo::myStream()</aux><aux></aux><aux></aux>
				<aux>ObjSendAudioTo::friendStream()</aux><aux></aux><aux></aux><aux></aux>
			</socialAux>
				<raitingAux>
					<aux>ObjStreamPositionGood</aux><aux>ObjStreamPositionBad</aux><aux>ObjStreamGoodLoop</aux><aux></aux>
					<aux>ObjStreamPositionMisstake</aux><aux>ObjStreamPositionClaim</aux><aux>ObjStreamClaim</aux><aux></aux>
				</raitingAux>
			<communicationAux>
				<aux></aux><aux></aux><aux></aux><aux></aux>
				<aux></aux><aux></aux><aux></aux><aux></aux>
			</communicationAux>
			<audioEventsAuxDisplay>
				<aux></aux><aux></aux><aux></aux><aux></aux>
				<aux></aux><aux></aux><aux></aux><aux></aux>
			</audioEventsAuxDisplay>
			//ObjectAudioTags;
			//ObjectPlayerButtonPLay;
		</audioFile>