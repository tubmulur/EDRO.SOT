<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
//////   /\ RCe:b=bool;	obj=object; 	[E] Event		     E={E} arrEvent	=array('Url1', 'Url2', ...);
   //  <  **> 	str=String;int=integer;	[D] Design/Destination/ToDo  D={D} arrDesign	=array('EventTemplate1', 'EventTemplate2', ...);
 //     Jl   	arr=array;		[R] Reality/Role/Permissions R={R} arrReality	=array('EventTemplate1Dj', 'EventTemplateMc', ...);
////// 2020	_Func=return nothing	[O] Objects O={R:{E:{D}}}    
class Design extends Event
	{
	public $arrrHtml;
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default')
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		parent::__construct($objKIIM);

		$this->arrrHtml=$this->arrGetHtmlDesign();


		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function arrGetHtmlDesign()
		{
		//$arr['audioFile']		=DesignAudioFile::html();
		//$arr['directory']		=DesignDirectory::html();
		//$arr['textFile']		=DesignTextFile::html();
		//$arr['formConstructorFile']	=DesignFormConstructor::html();
		//$arr['audioConstructorFile']	=DesignAudioConstructor::html();
		}
	}
?>