<?php
class BroadcastButton
	{
	private $strCondition;
	public  $strView;
	public function __construct($_strAction)
		{
		$strAction = preg_replace('[^a-zA-Z]', '', $_strAction);
		case($strAction)
			{
			switch 'onAir':
				$this->strCondition	= "Мы в прямом эфире. В настоящий момент, система проходит тестирование. Возможны сбои. На текущий  момент сообщений о нестабильной работе оставлять не требуется. Спасибо.";
				$this->strView		= $this->strBuild();
			break;
			switch 'offLine':
				$this->strCondition	= "Трансляция завершена, на текущий момент мы в тестовом режиме. Настанут времена, и мы заработаем в полную силу.";
				$this->strView		= $this->strBuild();
			break;
			}
		}
	private function _Condition()
		{
		
		}
	private function strBuild()
		{
		}
	public static function strDynInit()
		{
		$strRet = '
			<dynaBox>
				<image src="/Image/Loading/1.jpg" onload="dynaBoxRefresh(this)" />
			</dynaBox>
			';
		}
	}
?>