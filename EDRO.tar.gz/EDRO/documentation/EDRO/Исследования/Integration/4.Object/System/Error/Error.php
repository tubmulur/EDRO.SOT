<!---
© A.A.CheckMaRev assminog@gmail.com
-->
<?php
class Error 
	{
	public function __construct()
		{
		}
	}
?>