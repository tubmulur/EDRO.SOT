<!---
© A.A.CheckMaRev assminog@gmail.com
-->
<?php
class Image
	{
	private $_strDjName	='';
	private $strDjName	='Not found, please contact us';
	private $strImageLink	='';
	private $_strImageLink	='';
	//private $strAlt		='';
	//private $strTitle	='';
	public function __construct($_arrData(
			'_strDjName'	=>'',
			'_strImage'	=>'',
			'_strAlt'	=>'',
			'_strTitle'	=>''
			)
		)
		{
		//1.E
		//2.D
		//3.R
		//4.O

		$this->_strDjName	=$_arrData['_strDjName'];
					$this->_ProcessDjName();

		$this->_strImageLink	=$_arrData['_strImage'];
					$this->_ProcessImageLink();

		//$this->strAlt		=$_arrData['_strAlt'];
		//$this->strTitle	=$_arrData['_strTitle'];

					$this->_View();
		}
	private function _ProcessDjName()
		{
		$this->strDjName	=$this->_strDjName;
		}
	private function _ProcessImageLink()
		{
		$this->strImageLink	=$this->_strImageLink;
		}
	private function _View()
		{
		/*
		global $strDjName;
		$_strDjName	= $strDjName;
		global $strImage;
		$_strImage	= $strImage;
		*/
		echo '<image title="'.$this->strDjName.'" src="'.$this->strImageLink.'" style="width:100%"/>';
		}
	private function _Error()
		{
		}
	public static function Show($_arrData)
		{
		$objImage=new Image($_arrData)
		$objImage->_View;
		}
	}
?>