<!---
© A.A.CheckMaRev assminog@gmail.com
-->
<?php
class DjButton
	{
	private $strGlobalUserRole='Guest';
	private $strView;
	public function __construct()
		{
		$this->_Process_arrGlobalEnviroment();
		$this->_Design();
		// UserRole-?
		$this->strView=$this->objImage();
		$this->strView.=$this->objText();
		// 1E $_arrGlobalEnviroment
		// 2D _View
		// 3R _
		// 4O
		}
	}
?>
