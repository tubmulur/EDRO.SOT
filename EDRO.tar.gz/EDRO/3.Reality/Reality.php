<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
//////   /\ RCe:b=bool;	obj=object; 	[E] Event		     E={E} arrEvent	=array('Url1', 'Url2', ...);
   //  <  **> 	str=String;int=integer;	[D] Design/Destination/ToDo  D={D} arrDesign	=array('EventTemplate1', 'EventTemplate2', ...);
 //     Jl   	arr=array;		[R] Reality/Role/Permissions R={R} arrReality	=array('EventTemplate1Dj', 'EventTemplateMc', ...);
////// 2020	_Func=return nothing	[O] Objects O={R:{E:{D}}}
/*
Reality = array(
	language
	
	)
*/
class Reality extends Design
	{
	//protected $objReality;
	protected $arrReality	=array(
					'strRoles'	=>array(
						'Listener'
						),
					'strLanguage'	=>array(
						'RU'
						),
					'arrLastState'	=>array(
						),
					);
	public function __construct($_objKIIM, $_arrData=array())
		{
		$objKIIM=$_objKIIM;unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));

		parent::__construct($objKIIM);						//1[!]
		
		//$this->arrReality['arrRoles']		= new Role($objKIIM);		//2[!]
		//$this->arrReality['strLanguage']	= new Language($objKIIM);	//3[!]
		//$this->arrReality['arrLastState']	= new LastState($objKIIM);	//4[!]

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	/*
	private function arrGetLastState()
		{
		}
	*/
	}
?>
