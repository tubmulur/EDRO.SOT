<!--
//Copyright © assminog@gmail.com Andrey A. Chekmarev
-->
<html
	lang="ru"
	xml:lang="ru"
	style="
		position:fixed;
		z-index:1;
		"
	>
	<!--
	Made by ИП Чекмарёв А.А. assminog@gmail.com
	-->
	<head>
		<title>CloudRepublic.ru and HiFiIntelligentClub</title>
		<meta http-equiv="expires" content="Tue, 18 Dec 2019 18:52:06 GMT"/>
		<meta name="milliseconds" content=".1282">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<meta charset="utf-8"/>
		<!--link rel="manifest" href="/manifest.json"/-->
	</head>
		<style>
			/*RCe father*/
			body		{font-family:sans-serif;}
			.feetScreen	{width:100vw;height:93.5vh;}
			
			/*RCe matrix*/
			.matrixTop	{position:fixed;top:0px;}
			.matrixLeft	{position:fixed;top:40px;left:0;}
			.matrixRight	{position:fixed;top:40px;right:0;}
			.matrixBottom	{position:fixed;bottom:0px;}
			/*//RCe matrix*/

			/*RCe player*/
			/*/RCe.Author.table*/
			audioRecord {border-top: 1px solid #aaa;border-bottom: 1px solid #aaa;}
			audioRecord:hover {background-color:#ccc;}
			/*//RCe player*/

			  /*RCe base*/
			window 		{}
			.block		{display:block;overflow:hidden;}
			.rel		{position:relative;}
			.abs		{position:absolute;}
			.fixed		{position:fixed;}
			.left		{float:left;}
			.right		{float:right;}
			.scrollerY	{overflow-x:hidden;overflow-y:scroll;height:100vh;}
			.scrollerGlide	{-webkit-overflow-scrolling:touch;}
			.border		{border:1px solid #aaa}
			 /*//RCe base*/          

			  /*RCe layers*/
			.layer_1 {z-index:1;}
			.layer_1_1{z-index:2;}
			.layer_1_2{z-index:3;}
			.layer_1_3{z-index:4;}
			.layer_1_4{z-index:5;}

			.layer_2 {z-index:20;}
			.layer_2_1{z-index:21;}
			.layer_2_2{z-index:22;}
			.layer_2_3{z-index:23;}
			.layer_2_4{z-index:24;}

			.layer_3 {z-index:30;}
			.layer_3_1{z-index:31;}
			.layer_3_2{z-index:32;}
			.layer_3_3{z-index:33;}
			.layer_3_4{z-index:34;}

			.layer_4 {z-index:40;}
			.layer_4_1{z-index:41;}
			.layer_4_2{z-index:42;}
			.layer_4_3{z-index:43;}
			.layer_4_4{z-index:44;}
			/*//RCe layers*/
			
		</style>
	<body>
<?php

function _Image()
	{
	global $strDjName;
	$_strDjName	= $strDjName;
	global $strImage;
	$_strImage	= $strImage;
	echo '<image title="'.$_strDjName.'" src="'.$_strImage.'" style="width:100%"/>';
	}
function strNameVallue($_arrName=array("_strStyle"=>"","_strName"=>''),$_arrValue=array("_strStyle"=>"","_strName"=>''))
	{
	$strSize='';
	$strNameLeft='left';
	$strValueLeft='left';
	$str='<element class="block">';
	if(!empty($_arrName['_strName']))
		{
		if(!empty($_arrName['_strLeft']))
			{
			$strNameLeft=$_arrName['_strLeft'];
			}
		$str.='<title class="block '.$strNameLeft.'" style="width:120px;'.$_arrName['_strStyle'].'">'.$_arrName['_strName'].'</title>';
		}
	if(!empty($_arrValue['_strName']))
		{
		if(!empty($_arrValue['_strLeft']))
			{
			$strValueLeft=$_arrValue['_strLeft'];
			}
		if(!empty($_arrValue['_strSize']))
			{
			$strSize='<unitSize class="block left"> '.$_arrValue['_strSize'].'</unitSize>';
			}
		$str.='<value class="block '.$strValueLeft.'" style="width:188px;'.$_arrValue['_strStyle'].'" class="block left">'.$_arrValue['_strName'].'</value>'.$strSize;
		}
	$str.='</element>';
	return $str;
		
	}
function strRecordInfo($_arr)
	{
	/*
	Состав  произведения:
	Коипозиция <?=$arrTrack['intNumber']?>:
	strTrackInfo($arrTrack);
	strLabelInfo($arrTrack['label']);
	'strOffset'	=> '00:00:00',
	'strOffsetTitle'=> 'Смещение',
	'strOffsetUnit'	=> 'Сек',
	'intNumberTitle'=> 'Часть',
	'intNumber'	=> 1,
	'strRecordType'	=> 'Цифровая копия',
	'strTrackName'	=> 'BentleyMusic - Квартирный вопрос',
	*/
	$str=	'<recordInfo class="block">'.
			'<about class="block">'.
				'<position class="block left">'.
					$_arr['intNumber'].
				':</position>'.
				'<!-- <header class="block hide">'.
					'Название композиции: '.
				'</header> -->'.
				'<name class="block" style="background-color: rgb(78, 76, 76);color: rgb(255, 255, 255);text-align: center;font-size: large;">'.
					$_arr['strRecordName'].
				'</name>'.
			'</about>'.
			'<recordCover>'.
				'<img src="'.$_arr['strRecordCover'].'" style="width:100%"/>'.
			'</recordCover>'.
			'<type class="block">'.
				'<header class="block left" style="margin:0px 2px 0px 0px;width: 44%;">'.
					'Тип записи: '.
				'</header>'.
				'<data class="block">'.
					$_arr['strRecordType'].
				'</data>'.
			'</type>'.
			'<offset class="block">'.
				'<title class="block left" style="margin:0px 4px 0px 0px;width: 44%;">'.
					'Начало: '.
				'</title>'.
				'<time class="block left" style="margin:0px 2px 0px 0px;">'.
					$_arr['strOffset'].
				'</time>'.
				'<units class="block">'.
					$_arr['strOffsetUnit'].
				'</units>'.
			'</offset>'.
		'</recordInfo>';
	return $str;
	}
function strStudioInfo($_arr)
	{
	$str='';
	foreach($_arr as $_arrUnit)
		{
		'strName'
		'strWork'
		'strInstrument'
		'strYear'
		'strPosition'
		}
	return $str;
	}
function strAuthortInfo($_arr)
	{
	$str='';
	foreach($_arr as $_arrUnit)
		{
		$str.='<workAuthor class="block" style="border:1px solid #eee;">';
		if(!empty($_arrUnit['strName']))
			{
			$str.='<position class="block" >';
				$str.='<position class="block left" style="width:44%;">';
					$str.=$_arrUnit['strPosition'];
				$str.='</position>';
				$str.='<authorName class="block" >';
					$str.=': '.$_arrUnit['strName'];
				$str.='</authorName>';
			$str.='</position>';
				if(!empty($_arrUnit['strInstrument']))
				{
				$str.='<instrument class="block">'.
					'<title class="block left" style="width:44%;">'.
						'Инструмент'.
					'</title>'.
					'<title class="block">:'.
						$_arrUnit['strInstrument'].
					'</title>'.
				'</instrument>';
				}
			if(!empty($_arrUnit['strWork']))
				{
				$str.='<work class="block">'.$_arrUnit['strWork'].'</work>';
				}
			if(!empty($_arrUnit['strYear']))
				{
				$str.='<year class="block">'.$_arrUnit['strYear'].'</year>';
				}
			
			}
		$str.='</workAuthor>';
		}
	return $str;
	}
function strLabelInfo($_arr=array(
		'strLabelLogo'	=> 'img',
		'strLabelName'	=> '',
		)
	)
	{
	if(!empty($_arr['strLabelLogo']))
		{
		$str='Логотип: <LabelLogo>'.$_arr['strLabelLogo'].'</LabelLogo>';
		}
	if(!empty($_arr['strLabelName']))
		{
		$str.='Лейбл: <LabelName>'.$_arr['strLabelName'].'</LabelName>';
		}
	else
		{
		$str.='Лейбл: <LabelName> Не определён. Пожалуйста добавьтесь.</LabelName>';
		}

	return $str;
	}
function strLabelImage($_arr)
	{
	$str.='<img src="'.$_arr['strLabelImage'].'" alt="'.$_arr['strLanelType'].' '.$_arr['strLanelName'].'" style="width:100%;"/>';
	return $str;
	}
function strLabelContacts($_arr=array(
		'strCountryTitle'=>'',
		'strCountry'=>'',

		'strCityTitle'=>'',
		'strCity'=>'',

		'strDisrictTitle'=>'',
		'strDisrict'=>'',

		'strEmailTitle'=>'',
		'strEmail'=>'',

		'strTelegramTitle'=>'',
		'strTelegram'=>'',

		'strWatsappTitle'=>'',
		'strWatsapp'=>'',

		'strViberTitle'=>'',
		'strViber'=>'',

		'strICQTitle'=>'',
		'strICQ'=>'',

		'strVkTitle'=>'',
		'strVk'=>'',

		'strFacebookTitle'=>'',
		'strFacebook'=>'',
		)
	)
	{
	$str='';
	if(!empty($_arr['strCountry']))
		{
		$str.='
		<Country	name="'.$_arr['strCountryTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strCountryTitle'].':'),array('_strName'=>$_arr['strCountry'])).'</Country>';
		}
	if(!empty($_arr['strCity']))
		{
		$str.='			
		<City		name= "'.$_arr['strCityTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strCityTitle'].':'),array('_strName'=>$_arr['strCity'])).'</City>';
		}
	if(!empty($_arr['strDistrict']))
		{
		$str.='
		<District	name="'.$_arr['strDistrictTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strDistrictTitle'].':'),array('_strName'=>$_arr['strDistrict'])).'</District>';
		}
	if(!empty($_arr['strContactEmail']))
		{
		$str.='
		<email 		name="'.$_arr['strContactEmailTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactEmailTitle'].':'),array('_strName'=>$_arr['strContactEmail'])).'</email>';
		}
	if(!empty($_arr['strContactTelegram']))
		{
		$str.='				
		<telegram	name="'.$_arr['strContactTelegramTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactTelegramTitle'].':'),array('_strName'=>$_arr['strContactTelegram'])).'</telegram>';
		}
	if(!empty($_arr['strContactWhatsapp']))
		{
		$str.='	
		<whatsapp 	name="'.$_arr['strContactWhatsappTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactWhatsappTitle'].':'),array('_strName'=>$_arr['strContactWhatsapp'])).'</whatsapp>';
		}
	if(!empty($_arr['strContactViber']))
		{
		$str.='
		<viber		name="'.$_arr['strContactViberTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactViberTitle'].':'),array('_strName'=>$_arr['strContactViber'])).'</viber>';
		}
	if(!empty($_arr['strContactSkype']))
		{
		$str.='
		<skype		name="'.$_arr['strContactSkypeTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactSkypeTitle'].':'),array('_strName'=>$_arr['strContactSkype'])).'</skype>';
		}
	if(!empty($_arr['strContactICQ']))
		{
		$str.='
		<icq 		name="'.$_arr['strContactICQTitle'].'">'.strNameVallue(array('_strName'=>$_arr['strContactICQTitle'].':'),array('_strName'=>$_arr['strContactICQ'])).'</icq>';
		}
	if(!empty($_arr['strContactVk']))
		{
		$str.='
		<vk 		name="'.$_arr['strContactVkTitle'].'" >'.strNameVallue(array('_strName'=>$_arr['strContactVkTitle'].':'),array('_strName'=>$_arr['strContactVk'])).'</vk>';
		}
	if(!empty($_arr['strContactFacebook']))
		{
		$str.='
		<facebook 	name="'.$_arr['strContactFacebookTitle'].'">'.strNameVallue(array('_strName'=> $_arr['strContactFacebookTitle'].':'),array('_strName'=>$_arr['strContactFacebook'])).'</facebook>';
		}
	return $str;
	};
?>
<!--
Article programma constructor.
-->
<?php
//1 DATE PUBLISH
$arrRecord	= array(
	'RU'=>array(
		//2 Ddjmix
		'strDatePublished'	=> "Fri 20.DEC.2019 23:50:22.7237",
		'strDjMixTitle'		=> "radio selection 2018",
		'strDjMixName'		=> "LastDayRadio last  record",
		'strImage'		=> "https://sun9-33.userapi.com/c854020/v854020812/1b01ad/mxOxABpcQGc.jpg",
		'strMixFile'		=> "/music/CloudRepublic.Ru/Dj/Assminog/CloudRepublic.Ru_assminog_crashed_from_LastDayRadio.COM.mp3",
		//3 DJ+MC
		'strDjType'		=> "Dj",
		$strDjName		=> "Assminog",
		),
	);
$strDatePublished		= "Fri 20.DEC.2019 23:50:22.7237";

//2 Ddjmix
$strDjMixTitle			= "radio selection 2018";
$strDjMixName			= "LastDayRadio last  record";
$strImage			= "https://sun9-33.userapi.com/c854020/v854020812/1b01ad/mxOxABpcQGc.jpg";
$strMixFile			= "/music/CloudRepublic.Ru/Dj/Assminog/CloudRepublic.Ru_assminog_crashed_from_LastDayRadio.COM.mp3";

//3 DJ+MC
$strDjType			= "Dj";
$strDjName			= "Assminog";
$strMcType			= "MC";
$strMc				= "Assminog";
$strPublisherType		= "";
//$strAuthorTitle		= "Author";
//$strAuthor			= "Dj Assminog";

//4 PUBLISHER
$strPublisherlType		= "Record-label";
$strPublisherName		= "CloudRepublic.Ru";

//5 LABEL
//$strPublisherName		=> "DjAssminog";
$arrContacts4Integrate	= array(
	'RU'=>array(
		'strSite'			=> "",
		'strCountryTitle'		=> "Country",
		'strCountry'			=> "Russia",
		'strCityTitle'			=> "City",
		'strCity'			=> "Sankt-Petersburg",
		'strDistrictTitle'		=> "District",
		'strDistrict'			=> "World Wide Admiralteyskiy paradise district",
    		'strContactEmailTitle'		=> "Email",
		'strContactEmail'		=> "assminog@gmail.com",
		'strContactTelegramTitle'	=> "Telegram",
		'strContactTelegram'		=> '<a href="https://t.me/hifiint" target="_blanc">hifiint</a>',
		'strContactWhatsappTitle'	=> "Whatsapp",
		'strContactWhatsapp'		=> "+7(911)787-44-57",
		'strContactViberTitle'		=> "Viber",
		'strContactViber'		=> "--none--",
	    	'strContactSkypeTitle'		=> "Skype",
		'strContactSkype'		=> "--none--",
		'strContactICQTitle'		=> "ICQ",
		'strContactICQ'			=> "--none--",
		'strContactVkTitle'		=> "Vk",
		'strContactVk'			=> '<a href="https://vk.com/hifiintelligentclub">hifiintelligentclub</a>',
		'strContactFacebookTitle'	=> "FaceBook",
		'strContactFacebook'		=> "--none--",
		)
	);
$arrCover4Integrate = array(
	'RU'=>array(
		'strType'			=> "Record label", 
		'strName'			=> "CloudRepublic.Ru",
		'strImage'			=> "https://sun9-40.userapi.com/c855436/v855436069/208502/2ue6_1D1ftQ.jpg",
		'strSite'			=> "http://cloudrepublic.ru",
		'strCountry'			=> "Russia",
		'strContactEmail'		=> "",
		
		)
	);

$arrLabel			=	array(
	'RU'	=>array(
//Title(Visuals)
//	{
//	strLanguage
//		{
//		strName
//		strLogo
//		License
//		}
//	}
//Address
//	{
//	
//	
//	
//	
//	}
//|strName	|interactiveCover(Contact)	|
//|Email	: <a href="mailto:assminog@gmail.com">assminog@gmail.com</a>
//|Whatsapp	: <a href="whatsapp://send?abid=phonenumber&text=Hello%2C%20World!">Send Message</a>
//|Phone	: <a href="tel:assminog@gmail.com">assminog@gmail.com</a>
//arrElectronicContactServicesTemplates
//	{
//	'Email'=>array(
//		'EN'=>array(
//			'Email'			=>'<a href="mailto:{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Email',
//		),
//		'RU'=>array(
//			'Электронная почта'	=>'<a href="mailto:{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Электронная почта',
//		),
//	'Telegram'=>array(
//		'EN'=>array(
//			'Telegram'		=>'<a href="https:://t.me/{Contact}" target="_blanc">{Contact}</a>',
//			'actionContactName'	=>'Telegram link',
//			)
//		'RU'=>array(
//			'Телеграм'		=>'<a href="https:://t.me/{Contact}" target="_blanc">{Contact}</a>',
//			'actionContactName'	=>'Ссылка на Телеграм',
//			)
//		),
//	'Whatsapp'=>array(
//		'EN'=>array(
//			'Whatsapp'=>'<a href="whatsapp://send?abid={Contact}&text=Hello, im from RCe.">{Contact}</a>',
//			'actionContactName'	=>'Phone number',
//		)
//		'RU'=>array(
//			'Whatsapp'=>'<a href="whatsapp://send?abid={Contact}&text=Hello, im from RCe.">{Contact}</a>',
//			'actionContactName'	=>'Номер телефона',
//		)
//	'VK'=>array(
//		'EN'=>array(
//			'VK'			=>'<a href="https://vk.com/{Contact}">{actionContactName}</a>',
//			'actionContactName'	=>'Vk link',
//			''
//			),
//	'VK'=>array(
//		'RU'=>array(
//			'ВК'			=>'<a href="https://vk.com/{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Ссылка на ВК',
//			),
//		),
//	'Skype'=>array(
//		'EN'=>array(
//			'Skype'			=>'<a href="callto:{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Phone number',
//			),
//		'RU'=>array(
//			'Скайп'			=>'<a href="callto:{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Номер телефона Скайп',
//			)
//		),
//	'Viber'=>array(
//		'EN'=>array(
//			'Viber'			=>'<a href="viber://add?number={Contact}">{actionContact}</a>',
//			'actionContactName'	=>'Phone number',
//			)
//		'RU'=>array(
//			'Вайбер'		=>'<a href="viber://add?number={Contact}">{actionContact}</a>',
//			'actionContactName'	=>'Номер телефона',
//			)
//		),
//	'ICQ'=>array(
//		'EN'=>array(
//			'ICQ'			=>'{Contact}',
//			'actionContactName'	=>'ICQ number',
//			)
//		'RU'=>array(
//			'ICQ'			=>'{Contact}",
//			'actionContactName'	=>'Номер ICQ',
//			)
//	'Facebook'=>array(
//		'EN'=>array(
//			'Facebook'		=>'<a href="https://facebook.com/{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Facebook link',
//			)
//		'RU'=>array(
//			'Фейсбук'		=>'<a href="https://facebook.com/{Contact}">{Contact}</a>',
//			'actionContactName'	=>'Ссылка на Фейсбук',
//			)
//		),
//	}
//arrElectronicContactServices
//	{
//	'Email'	=>array(
//		'EN' => array(
//			'Contact'		=> 'assminog@gmail.com',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Email']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> 'tubmulur@yandex.ru',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Email']['RU']',
//
//		),
//	'Telegram'	=>array(
//		'EN' => array(
//			'Contact'		=> 'hifiint',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Telegram']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> 'hifiint',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Telegram']['RU']',
//
//		),
//	'Whatsapp'	=>array(
//		'EN' => array(
//			'Contact'		=> '+79117874457',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Whatsapp']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> '+79117874457',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Whatsapp']['RU']',
//
//		),
//	'Viber'	=>array(
//		'EN' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Viber']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Viber']['RU']',
//
//		),
//	'Skype'	=>array(
//		'EN' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Skype']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['Skype']['RU']',
//
//		),
//	'ICQ'	=>array(
//		'EN' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['ICQ']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> '',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['ICQ']['RU']',
//
//		),
//	'VK'	=>array(
//		'EN' => array(
//			'Contact'		=> 'assminog',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['VK']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> 'assminog',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['VK']['RU']',
//
//		),
//	'FACEBOOK'	=>array(
//		'EN' => array(
//			'Contact'		=> 'assminog',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['FACEBOOK']['EN']',
//
//		),
//		'RU' => array(
//			'Contact'		=> 'assminog',
//			'actionTemplate'	=> 'ElectronicContactServicesTemplates['FACEBOOK']['RU']',
//
//		),
//	}
//arrElectronicContact  
//	{		
//	Name	=>Language
//	Action	=> '<a href=">https://t.me/hifiint">HifiIntelligentClub</a>',
//	}

//Contacts
//	{
//	arrLanguage
//		arrElectronic
//			{
//			Name
//			NameType
//			Type
//			ServiceName
//			ServiceLink
//			}
//		Physical
//		{
//		Title
//		
//		}
//	}
//Contacts
	//
	//Presentation Visuals
		//Language
			//Name
			//Logo
		//Contacts
			//Language
		
	//Detailed info
		//Points->Contacts
		
	//Products

	'strLabelType'			=> "Record label", 
	'strLabelName'			=> "CloudRepublic.Ru",
	'strLabelImage'			=> "https://sun9-40.userapi.com/c855436/v855436069/208502/2ue6_1D1ftQ.jpg",
	'arrPoints'=>array(
			'strName'			=> '',

			),
		),
	);

//5 RecordLIST
$arrRecordList	= array(
	array(
		'RU'=>array(
			array(  //Record
				'strRecordName'	=> 'BentleyMusic - Квартирный вопрос',
				'strOffset'	=> '00:00:00',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Часть',
				'intNumber'	=> 1,
				'strRecordType'	=> 'Цифровая копия',
				'strRecordCover'=> 'https://sun9-53.userapi.com/c847217/v847217647/15bca3/PoP9GTgPtDI.jpg',
				),
			'arrLabel'=>array(
				'RU'=>array(
					'strLabelLogo'			=> '',
					'strLabelName'			=> 'ИП Чекмарёв А.А.',
					'strCountryTitle'		=> 'Страна',
					'strCountry'			=> 'Россия',
					'strCityTitle'			=> 'Город',
					'strCity'			=> 'Санкт-Петербург',
					'strDistrictTitle'		=> 'Район',
					'strDistrict'			=> 'Адмиралтейский р-н',
					'strContactEmailTitle'		=> 'Электронная почта',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Телеграм:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
    	    				'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",
					),
				'arrAuthors'=>array(
					'RU'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Автор',
							),
						),
					),
				'arrAdmWorkers'=>array(
					'RU'=>array(
						    array(
							'arrDirector'=>array(
								array(
									'strName'	=> 'Чекмарёв А.А.',
									'strPosition'	=> 'Директор',
									),
								),
							),
						),
					),
    				/* 'arrTechWorkers'=>array(
					'RU'=>array(
						    array(
							),
						),
					),
				*/
    				'arrMusicians'=>array(
					'RU'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Исполнитель',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strInstrument'	=> 'ZzzuzzZ Sintesizer',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Автор гармонии',
							),
						array(
								'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Аранжировщик',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Коипозитор',
							),
						array(
							'strName'	=> 'Циринский И.С.',
							'strPosition'	=> 'Техническое оснащение',
							),
						),
					),
    				'arrArtists'=>array(
					'RU'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Вокалист',
							),
						),
					),
				'arrWriters'=>array(
					'RU'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Поэт',
							),
						),
					),
				'arrGraphicalWorkers'=>array(
					'RU'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Дизайнер логотипа',
							),
						),
					),
				'arrStudios'=>array(
					array(
						'RU'=>array(
							'strStudioName'			=> 'LRecords',
							'strStudioImage'		=> "https://sun9-40.userapi.com/c855436/v855436069/208502/2ue6_1D1ftQ.jpg",
							'strStudioSite'			=> 'LRecords',
							'strCountryTitle'		=> "Country",
							'strCountry'			=> "Russ	ia",
							'strCityTitle'			=> "City",
							'strCity'			=> "Sankt-Petersburg",
							'strDistrictTitle'		=> "District",
							'strDistrict'			=> "World Wide Admiralteyskiy paradise district",
							'strContactSite'		=> 'http://',
							'strContactEmailTitle'		=> "Email",
							'strContactEmail'		=> "igor.zirinskiy@gmail.com",
							'strContactTelegramTitle'	=> "Telegram",
						    	'strContactTelegram'		=> '--none--',
					    		'strContactWhatsappTitle'	=> "Whatsapp",
							'strContactWhatsapp'		=> "--none--",
							'strContactViberTitle'		=> "Viber",
							'strContactViber'		=> "--none--",
							'strContactSkypeTitle'		=> "Skype",
		    					'strContactSkype'		=> "--none--",
							'strContactICQTitle'		=> "ICQ",
							'strContactICQ'			=> "--none--",
							'strContactVkTitle'		=> "Vk",
							'strContactVk'			=> '<a href="https://vk.com/zzzuzzz">Оборудование ZzzuzzZ</a>',
							'strContactFacebookTitle'	=> "FaceBook",
						    	'strContactFacebook'		=> "--none--",
							),
	    				'arrAdmWorkers'=>array(
						'RU'=>array(
							array(
								'strName'	=> 'Циринский И.С.',
	    							'strWork'	=> 'Творческий посыл',
								'strInstrument'	=> 'ZzzuzzZ EQ1',
								'strYear'	=> '2012г',
								'strPosition'	=> 'Директор',
								),
							array(
								'strName'	=> 'Чекмарёв А.А.',
								'strWork'	=> 'Создание муз. произведения',
								'strInstrument'	=> 'Блокнот',
								'strYear'	=> '2012г',
								'strPosition'	=> 'Исполнительный продюссер',
								),
							),
						),
					'arrTechWorkers'=>array(
						'RU'=>array(
							array(
								'strName'	=> 'Тесёлкин М.',
	        						'strWork'	=> 'Ритмические нюансы',
								'strInstrument'	=> 'Piano roll',
								'strYear'	=> '2012г',
								'strPosition'	=> 'Инженер',
								),
							array(
								'strName'	=> 'Чекмарёв А.А.',
		    						'strWork'	=> 'Арранжировка',
								'strInstrument'	=> 'ZzzuzzZ Arrangement',
								'strYear'	=> '2012г',
								'strPosition'	=> 'Инженер',
								),
							),
						),
					'arrSessionMusicians'=>array(
							'RU'=>array(
								array(
								'strName'	=> 'Тесёлкин М.',
								'strWork'	=> 'Ритмические нюансы',
								'strInstrument'	=> 'Piano roll',
								'strYear'	=> '2012г',
								'strPosition'	=> 'Барабанщик',
								),
							),
						),
					'arrStudios'=>	array(
						'RU'=>array(
							'strStudioName'			=> 'Адмиралтейский пэрэдайз',
							'strStudioImage'		=> "",
							'strCountryTitle'		=> "Country",
							'strCountry'			=> "Russia",
							'strCityTitle'			=> "City",
							'strCity'			=> "Sankt-Petersbourg",
							'strDistrictTitle'		=> "District",
							'strDistrict'			=> "World Wide Admiralteyskiy paradise district",
							'strContactSite'		=> 'https://hifiintelligentclub.ru',
							'strContactEmailTitle'		=> "Email",
							'strContactEmail'		=> "assminog@gmail.com",
							'strContactTelegramTitle'	=> "Telegram",
							'strContactTelegram'		=> '--none--',
							'strContactWhatsappTitle'	=> "Whatsapp",
							'strContactWhatsapp'		=> "--none--",
							'strContactViberTitle'		=> "Viber",
							'strContactViber'		=> "--none--",
							'strContactSkypeTitle'		=> "Skype",
							'strContactSkype'		=> "--none--",
							'strContactICQTitle'		=> "ICQ",
							'strContactICQ'			=> "--none--",
							'strContactVkTitle'		=> "Vk",
							'strContactVk'			=> '<a href="https://vk.com/assminog">Assminog</a>',
							'strContactFacebookTitle'	=> "FaceBook",
						    	'strContactFacebook'		=> "--none--",
							),
						'arrAdmWorkers'=>array(
							'RU'=>array(
								array(
									'strName'	=> 'Чекмарёв А.А.',
									'strWork'	=> 'ИП',
									'strInstrument'	=> 'ZzzuzzZ EQ1',
									'strYear'	=> '2012г',
									'strPosition'	=> 'Директор',
									),
								),
							),
						'arrTechWorkers'=>array(
							'RU'=>array(
								array(
									'strName'	=> 'Чекмарёв А.А.',
									'strPosition'	=> 'Мастеринг',
									),
								array(
									'strName'	=> 'Чекмарёв А.А.',
									'strPosition'	=> 'Балансировка аудио записи',
									),
								),
						'arrSessionMusicians'=>array(
							'RU'=>array(
								),
							),
						),
					),
				),
			),
	array(
				'strOffset'	=> '00:05:08',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 2,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Beautiful Now',
				'arrLabel'=>array(
					'strLabelName'			=> '',
					'strLabelLogo'			=> '',
					'strCountryTitle'		=> '',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
/*					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Zedd Feat.John Bellion',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:08:30',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 3,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Бедная Овечка (Аккустическая версия)',
				'arrLabel'=>array(
					'strLabelName'			=> '',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Алёна Свиридова',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:12:24',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 4,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Не определено N1273. Добавьтесь пожалуйста assminog@gmal.com',
				'arrLabel'=>array(
					'strLabelName'			=> '',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Не определено. Добавьтесь пожалуйста. assminog@gmal.com',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:13:34',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 5,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Малыш',
				'arrLabel'=>array(
					'strLabelName'			=> '',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Маяковская',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:17:22',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 6,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Николь',
				'arrLabel'=>array(
					'strLabelName'			=> '',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Чугунный скороход',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:21:57',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 7,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Лесной Олень',
				'arrLabel'=>array(
					'strLabelName'			=> 'Пиратская станция',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> '',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:21:57',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 7,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Лесной Олень',
				'arrLabel'=>array(
					'strLabelName'			=> 'Пиратская станция',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> '',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:25:34',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 8,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Что делать если поругался, не работает.',
				'arrLabel'=>array(
					'strLabelName'			=> 'CloudRepublic.Ru',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'TV',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:31:07',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 9,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> '',
				'arrLabel'=>array(
					'strLabelName'			=> 'CloudRepublic.Ru',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'TV',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),
/*1[1] */		array(
				'strOffset'	=> '00:31:07',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Номер',
				'intNumber'	=> 10,
				'strRecordType'	=> 'Цифровая копия',
/*2[1][arrLabel]*/		'strRecordName'	=> 'Breeze of the cape',
				'arrLabel'=>array(
					'strLabelName'			=> 'CloudRepublic.Ru',
/*					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Country',
					'strCountry'			=> '',
					'strCityTitle'			=> '',
					'strCity'			=> '',
					'strDistrictTitle'		=> '',
					'strDistrict'			=> '',
					'strContactEmailTitle'		=> '',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Telegram:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",*/
/*3[1][arrLabel][arrAuthor]*/		'arrAuthor'=>array(
/*4[1][arrLabel][arrAuthor][strName]*/		array(
							'strName'	=> 'Lalu',
							'strPosition'	=> 'Автор',
/*3*/							),
/*4*/						),
					'arrMusician'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Исполнитель',
							),
						),
/*3*/					'arrInstrumentalist'=>array(
/*4*/						array(
							'strName'	=> '',
							'strInstrument'	=>'',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
/*3*/						),
/*4*/					'arrHarmonist'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> '',
					
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> '',
							'strPosition'	=> 'Коипозитор',
							),
						),
/*3*/					'arrEngeneer'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> '',
							'strPosition'	=> 'Сведение',
							),
						),
/*3*/					'arrDirector'=>array(
/*4*/						array(
							'strName'	=> '',
							'strPosition'	=> 'Директор',
							),
						),
					),
				),

			);
?>
<!--
EOF.
-->
<debug class="block" style="width:320px">
<meta charset="utf-8">
<DjMix
	name	="<?=$strDjmixTitle?>"
	title	="<?=$arrLabel['strLabelType'].': '.$arrLabel['strLabelName'].', '.$strDjType.': '.$strDjName.', '.$strDjMixTitle.': '.$strDjMixName?>"
	date	="<?=$strDatePublished?>"
	class	="block scrollerY"
	style	="
		border-top:1px solid #aaa;
		border-bottom:1px solid #aaa;
		margin: 5px 0 5px 0;
		"
		>


		<h1 
			style="
				color: #000;
				margin-bottom: 0;
				
				"
			>
			<?=$arrLabel['strLabelName']?>
			<?=$arrLabel['strLabelType']?>
		</h1>
		<h2><?=strNameVallue(array('_strName'=>$strDjType.':'),array('_strName'=>$strDjName));?></h2>
		<datePublished><?=$strDatePublished?></datePublished>
		<h3><?=$strDjMixName?></h3>
			
		<audio controls>
			<source src="<?=$strMixFile?>"/>
	    	</audio>					
		<Publisher name="<?=$strPublisherlType.';'.$strPublisherName?>">
			<logo class="block">
				<?=strLabelImage($arrLabel);?>
			</logo>
			<Contacts class="block">
				<?=strLabelContacts($arrLabel);?>
			</Contacts>
			<dj name="<?=$strDjName?>">
				Состав  произведения:
				Композиции:
				<RecordList
					class="block"
					style="border: 1px solid #00"
					>
					<?php

					foreach($arrRecordList as $intI=>$arrRecord)
						{
						?>
						<audioRecord
							number="<?=$arrRecord['intNumber']?>"
							name="<?=$arrRecord['strName']?>"
							offsetSek="<?=$arrRecord['strOffset']?>"
							class="block"
							style="
								background-color:#DDD;
								"
							>
							<?php
							 echo strRecordInfo($arrRecord);
							//echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrAuthor']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrMusician']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrInstrumentalist']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrDj']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrHarmonist']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrArranger']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrComposer']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrEngeneer']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrDirector']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrVocalist']);
//							echo '<hr/>';
							echo strAuthortInfo($arrRecord['arrLabel']['arrPoet']);
//							echo '<hr/>';
							echo strStudioInfo($arrRecord['arrLabel']['arrStudio']);
//							echo '<hr/>';
							echo strLabelInfo($arrRecord['arrLabel']);
//							echo '<hr/>';
							echo strLabelContacts($arrRecord['label']);
//							echo '<hr/>';  
							?>
<?php
	/*				'arrAuthor'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Автор',
							),
						),
					'arrMusician'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Исполнитель',
							),
						),
					'arrInstrumentalist'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strInstrument'	=> 'ZzzuzzZ Sintesizer',
							'strPosition'	=> 'Исполнитель-инструменталист',
							),
						),
					'arrDj'=>array(
						array(
							'strName'	=> '',
							'strInstrument'	=>'Scratch',
							'strPosition'	=> 'Диджей',
							),
						),
					'arrHarmonist'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Автор гармонии',
							),
						),
					'arrArranger'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Аранжировщик',
							),
						),
					'arrComposer'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Коипозитор',
							),
						),
					'arrEngeneer'=>array(
						array(
							'strName'	=> 'Циринский И.С.',
							'strPosition'	=> 'Техническое оснащение',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Мастеринг',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Балансировка аудио записи',
							),
						array(
							'strName'	=> 'Тесёлкин М.',
							'strPosition'	=> 'Ритмические нюансы',
							),
						),
					'arrDirector'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Директор',
							),
						),
					'arrVocalist'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Вокалист',
							),
						),
					'arrPoet'=>array(
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strPosition'	=> 'Автор стихов',
							),
						),
					'arrStudio'=>array(
						array(
							'strName'	=> 'Циринский И.С.',
							'strWork'	=> 'Создание арранжировки',
							'strEquipment'	=> 'Оборудование ZzzuzzZ',
							'strPosition'	=> 'Студия Малый проспект п-с',
							),
						array(
							'strName'	=> 'Чекмарёв А.А.',
							'strWork'	=> 'Запись вокала, мастеринг, публикация',
							'strEquipment'	=> 'Оборудование ZzzuzzZ',
							'strPosition'	=> 'Троицкий пр адм. р-н',
							),
						),*/
?>
<?php /*
				'strOffset'	=> '00:00:00',
				'strOffsetTitle'=> 'Смещение',
				'strOffsetUnit'	=> 'Сек',
				'intNumberTitle'=> 'Часть',
				'intNumber'	=> 1,
				'strRecordType'	=> 'Цифровая копия',
		'strRecordName'	=> 'BentleyMusic - Квартирный вопрос',
				'arrLabel'=>array(
					'strLabelLogo'			=> 'img',
					'strCountryTitle'		=> 'Страна',
					'strCountry'			=> 'Россия',
					'strCityTitle'			=> 'Город',
					'strCity'			=> 'Санкт-Петербург',
					'strDistrictTitle'		=> 'Район',
					'strDistrict'			=> 'Адмиралтейский р-н',
					'strContactEmailTitle'		=> 'Электронная почта',
					'strContactEmail'		=> "assminog@gmail.com",
					'strContactTelegramTitle'	=> "Телеграм:",
					'strContactTelegram'		=> "<a href='https://t.me/hifiint' target='_blanc'>hifiint</a>",
					'strContactWhatsappTitle'	=> "Whatsapp:",
					'strContactWhatsapp'		=> "+7(911)787-44-57",
					'strContactViberTitle'		=> "Viber:",
					'strContactViber'		=> "--none--",
					'strContactSkypeTitle'		=> "Skype:",
					'strContactSkype'		=> "--none--",
					'strContactICQTitle'		=> "ICQ:",
					'strContactICQ'			=> "--none--",
					'strContactVkTitle'		=> "Vk:",
					'strContactVk'			=> "<a href='https://vk.com/hifiintelligentclub'>Vk</a>",
					'strContactFacebookTitle'	=> "FaceBook:",
					'strContactFacebook'		=> "--none--",
	'arrAuthor'=>array(
	array(
							'strName'	=> '',
							'strPosition'	=> 'Автор',
							),					),

							<?php /* ?>
							<?=strNameVallue(array('_strName'=>$arrRecord['strOffsetTitle'].':'),array('_strName'=>$arrRecord['strOffset'],'_strSize'=>$arrRecord['strOffsetUnit']));?>
							<?=strNameVallue(array('_strName'=>$arrRecord['arrAuthor']['strPosition'].':'),array('_strName'=>$arrRecord['arrLabel']['arrAuthor']['strName']));?>
							<?php */ ?>
						</audioRecord>
					<?php
					}
				?>
				</RecordList>
			</dj>
		</Publisher>
	</DjMix>
</debug>
</body>