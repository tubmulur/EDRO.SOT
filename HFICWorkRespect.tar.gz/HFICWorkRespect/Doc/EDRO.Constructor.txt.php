© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru
//////_________________________________(.)
   //            /\ RCe			E : Event
  //           <  **> [O]<-{R:{E:{D}}}  D : loadTemplateFor Event
 //              Jl EDRO->[E][D][R][O]  R :
//////-> 01.09.2016-12.03.2020->	O:{[R]:{[D]:{[E]}}}
//					     \    \    \_Инструкции____
//					      \    \
//					       \    \__Набор инструментов полный(Принадлежащий текущей реп точке)____
//					        \
//					         \__Набор инструментов принадлежный к [R]______




			---------------------------------------------------------
			|CONSTRUCTOR CHAIN[E]					|
			---------------------------------------------------------
			|CONSTRUCTOR CHAIN[D]					|
			---------------------------------------------------------
			|CONSTRUCTOR CHAIN[R]					|
			---------------------------------------------------------
			|Objects	  [O]			| O, O, O, O...	|
			---------------------------------------------------------


1>2>3>4>5>6>7>8>9>..>
EDRO=E>D>R>O=array[ALL WE CAN NOW]
if Object is in arrEDRO grant object 


FileList('/')					1.FileList('/') -> listnerCLick() -> FileList('/Folder1')
	|.LICENSE
	|Folder1
	|	EDRO.Folder1..LICENSE
	|	EDRO.Folder1..about.json-----|FileList('/Folder1')
	|	EDRO.Folder1..about.php------|
	|	EDRO.Folder1.Folder1_1-------|
	|	EDRO.Folder1.Folder1_2-------|
	|	EDRO.Folder1.Folder1_3-------|
	|	EDRO.Folder1.Folder1_4-------|
	|Folder2
	|	.LICENSE
	|	.about.json-----|FileList('/Folder2')
	|	.about.php------|
	|	Folder2_1-------|
	|	Folder2_2-------|
	|	Folder2_3-------|
	|	Folder2_4-------|
	|Folder3
	|	.LICENSE
	|	.about.json-----|FileList('/Folder3')
	|	.about.php------|
	|	Folder2_1-------|
	|	Folder2_2-------|
	|	Folder2_3-------|
	|	Folder2_4-------|
	|Folder4
	|	.LICENSE
	|	.about.json-----|FileList('/Folder4')
	|	.about.php------|
	|	Folder2_1_______|
	|	Folder2_2-------|
	|	Folder2_3-------|
	|	Folder2_4-------|



|---------------------------------------|
|					|
|---------------- ----------------------|
|		| |			|
|Folder1	| |Folder4		|
|		| |			|
|---------------- -----------------------
|		| |			|
|Folder2	| |                     |
|		| |			|
|---------------- -----------------------
|		| |			|
|Folder3	| |	DynaBlock	|
|		| |			|
----------------- -----------------------
|					|
|---------------------------------------|
                                             

HficArtistsRespect::html($objKIIM, $this->arr['_strCopyrightInfo']).
Shader::html($objKIIM, $this->strLogo).
Player::html($objKIIM, $this->strAudio).
Overlay::html($objKIIM, 'Loading. Please wait.').

FileList
	->construct
		_GetFolder();
		_Sort();
		_ApplyTemplate();
$arrTemplates	=array(
	''='',
	);

arr@strElementName=>array(
	arr@strLangName=>array(
		'strPropertyName'=>'strPropertyValue'
		)
	);

/File/_ApplyTemplate($objKIIM, $strFolder)
	{
	$arrElements=array(
		'Assminog'		=>array(
			'RU'=>array(
				'strName'=>'Assminog',
				'strType'=>'Musician',
				'strLogo'=>'https://sun9-6.userapi.com/c840538/v840538632/6bf91/DZERxXTa_Z0.jpg',
				),
			'EN'=>array(
				'strType'=>'Musician',
				),
			),

		'DayRadio'		=>array(
			'RU'=>array(
				'strName'=>'DayRadio',
				'strType'=>'Radio',
				'strLogo'=>'https://sun9-26.userapi.com/c830400/v830400498/1147d8/sRtHTd4tjjM.jpg',
				),
			'EN'=>array(
				'strType'=>'Radio',
				),
			),
		'DjVictory'		=>array(
			'RU'=>array(
				'strName'=>'DjVictory',
				'strType'=>'Композитор',
				'strLogo'=>'https://sun9-12.userapi.com/c206716/v206716766/127b5/A5zj_jP9qoI.jpg',
				),
			'EN'=>array(
				'strType'=>'Composer',
				),
			),
		'HiFiIntelligentClub'	=>array('
			RU'=>array(
				'strName'=>'HiFiIntelligentClub',
				'strType'=>'Club',
				'strLogo'=>'https://sun9-39.userapi.com/c846016/v846016022/f53a0/JxqAbAlyFjY.jpg',
				),
			'EN'=>array(
				'strType'=>'Club',
				),
			),
		'Lunatx'		=>array(
			'RU'=>array(
				'strName'=>'Lunatx',
				'strType'=>'Label',
				'strLogo'=>'https://sun9-63.userapi.com/c857220/v857220161/ca9dc/A4jO1I93xp0.jpg',
				),
			'EN'=>array(
				'strType'=>'Label',
				),
			),
		'Mark Shubin'		=>array(
			'RU'=>array(
				'strName'=>'Марк Шубин',
				'strType'=>'Композитор',
				'strLogo'=>'https://sun9-38.userapi.com/c626720/v626720808/3a472/1FyjTGAgMxM.jpg',
				),
			'EN'=>array(
				'strType'=>'Composer',
				),
			)
		'Sando Radiola'		=>array(
			'RU'=>array(
				'strName'=>'SandoRadiOlla',
				'strType'=>'Animations',
				'strLogo'=>'https://sun9-7.userapi.com/c848636/v848636417/110e9/6EgvWW0OB5Q.jpg',
				),
			'EN'=>array(
				'strType'=>'Animations',
				),
			)
		'Trip-Hop Opera'	=>array(
			'RU'=>array(
				'strName'=>'Trip-Hop Opera',
				'strType'=>'Group',
				'strLogo'=>'https://sun9-14.userapi.com/c855332/v855332226/1e5c77/KkUC3Wdxi3g.jpg',
				),
			'EN'=>array(
				'strType'=>'Group',
				),
			)
		'Victor Popov'		=>array(
			'RU'=>array(
				'strName'=>'Викторрисон',
				'strType'=>'MC',
				'strLogo'=>'https://sun9-64.userapi.com/c846416/v846416270/177ae8/XWvNIPUPQzs.jpg',
				),
			'EN'=>array(
				'strType'=>'MC',
				),
			)
		'Zzzzuzz'		=>array(
			'RU'=>array(
				'strName'=>'ZzzuzzZ',
				'strType'=>'Musician',
				'strLogo'=>'https://sun9-26.userapi.com/c851136/v851136347/8db84/TMFPXn0-Wzs.jpg',
				),
			'EN'=>array(
				'strType'=>'Musician',
				),
			)
		'группа Джига Дрыга'	=>array*(
			'RU'=>array(
				'strName'=>'Джига Дрыга',
				'strType'=>'Музыкальная группа',
				'strLogo'=>'https://sun9-47.userapi.com/c855216/v855216520/18abed/dTHdz_S2Uq8.jpg',
				),
			'EN'=>array(
				'strType'=>'Music group',
				),
			)
		'Маяковская78'		=>array(
			'RU'=>array(
				'strName'=>'Маяковская78',
				'strType'=>'ВИА',
				'strLogo'=>'https://sun9-19.userapi.com/c851128/v851128903/8a3b4/3tq9DOXF3Zc.jpg',
				),
			'EN'=>array(
				'strType'=>'VIA',
				),
			),
		'Модифицированная сингулярность'=>array('
			RU'=>array(
				'strName'=>'Модифицированная сингулярность',
				'strType'=>'Студия',
				'strLogo'=>'https://sun9-50.userapi.com/c845219/v845219596/173012/l5cQxj42THk.jpg',
				),
			'EN'=>array(
				'strType'=>'Студия',
				),
			),
		'Музыка для Бентли'	=>array(
			'RU'=>array(
				'strName'=>'Музыка для Бентли',
				'strType'=>'Альбом',
				'strLogo'=>'https://sun9-6.userapi.com/c840538/v840538632/6bf91/DZERxXTa_Z0.jpg',
				'strAudio'=>'http://cloudrepublic.music/Labels/CloudRepublic.Ru/Promotion/Assminog/CloudRepublic.Ru__Dj_Assminog__BentleyMusic - Квартирный вопрос.mp3',
				),
			'EN'=>array(
				'strType'=>'Альбом',
				),
			),
		'Полковник психологии'	=>array(
			'RU'=>array(
				'strName'=>'Полковник психологии Богдан Барбацун',
				'strType'=>'MC',
				'strLogo'=>'https://sun9-19.userapi.com/c850636/v850636121/1a1e22/dfi5Ne-p9DI.jpg',
				'strAudio'=>'http://cloudrepublic.music/Labels/CloudRepublic.Ru/Audio projects/Богдан Барбацун/Assminog/АдмиралтейскиеМенты.mp3',
				),
			'EN'=>array(
				'strType'=>'MC',
				),
			),
		'Слоники Суперкнижка'	=>array(
			'RU'=>array(
				'strName'=>'Слоники Суперкнижка',
				'strType'=>'Книга',
				'strLogo'=>'https://sun9-49.userapi.com/c850128/v850128584/672c2/o6vnnBwkzyo.jpg',
				),
			'EN'=>array(
				'strType'=>'Книга',
				),
			),
		'Собачий срок (dogSrok)'=>array(
			'RU'=>array(
				'strName'=>'Собачий срок (dogSrok)',
				'strType'=>'MC',
				'strLogo'=>'https://sun9-55.userapi.com/c847221/v847221844/17081a/yrA4obOOQL4.jpg',
				),
			'EN'=>array(
				'strType'=>'MC',
				),
			)
		'Тангенс арксинуса (tgArcSin)'=>array(
			'RU'=>array(
				'strName'=>'Тангенс арксинуса (tgArcsin)',
				'strType'=>'Musicians',
				'strLogo'=>'https://sun9-7.userapi.com/c844720/v844720596/16a89f/JnZubvfoGMc.jpg',
				),
			'EN'=>array(
				'strType'=>'Animations',
				),
			)
		'Техно студенты'	=>array(
			'RU'=>array(
				'strName'=>'Техно студенты',
				'strType'=>'Студия',
				'strLogo'=>'https://sun9-64.userapi.com/c205324/v205324825/52a15/7nd2zcLCs-Q.jpg',
				),
			'EN'=>array(
				'strType'=>'Студия',
				),
			)
		);
	}

array(
	''
);

I wish to have following file types:

	1.InputForm witch is extracted to the input form block;
	2.OutputBlock whitch is extracted to what are we can see inside.

$arrFileTemplate=array(
	
);

1) FileList:
	EDRO---------------------->[D]		 -----------------------
	Folder1					|			|
		EDRO--------------->[D]		-------------------------
	Folder2					|			}
		EDRO--------------->[D]		|			|
	File1					|			|
		EDRO				|			|
						 -----------------------


1. Описание структуры каталогов шаблонизатора процессов EDRO

1.1. /home/chekmarev/job/EDRO - наборы элементов необходимых для конструирования процессов описанных или оцифрованых в формате EDRO.
1.2. /home/chekmarev/job/EDRO/EDRO.php - Конструктор готового объекта EDRO.


2. Описание директорий верхнего уровня

    /home/chekmarev/job/EDRO/1.Event - Описанные или оцифрованные события, запускающие процесс.
    /home/chekmarev/job/EDRO/2.Design - Наборы матриц для формирования сложных элементов.
    /home/chekmarev/job/EDRO/3.Reality - Описанные или оцифрованные пользовальтеские реальности.
    /home/chekmarev/job/EDRO/4.Object - Набор плагинов, из которых состоит EDRO.


3. Описание вложенных директорий

3.1. /home/chekmarev/job/EDRO/1.Event - Описанные или оцифрованные события, запускающие процесс.
3.1.1. /home/chekmarev/job/EDRO/1.Event/Event.php - Обработчик событий системы EDRO. Не редактируемый ползователями.


3.2. /home/chekmarev/job/EDRO/2.Design - Наборы матриц для формирования сложных элементов.
3.2.1. /home/chekmarev/job/EDRO/2.Design/Design.php - Выборка (Фильтрация) подходящих для события матриц.


3.3. /home/chekmarev/job/EDRO/3.Reality - Описанные или оцифрованные пользовальтеские реальности.
3.3.1. /home/chekmarev/job/EDRO/3.Reality/Reality.php - Определение принадлежности пользователя к одной существующих реальностей.
3.3.2. /home/chekmarev/job/EDRO/3.Reality/Название реальности/ - описанная пользовательская реальность.
3.3.3. /home/chekmarev/job/EDRO/3.Reality/Название реальности/1.Event/
3.3.4. /home/chekmarev/job/EDRO/3.Reality/Название реальности/2.Design/


3.4. /home/chekmarev/job/EDRO/4.Object/ - Набор плагинов, из которых состоит EDRO.
3.4.1 /home/chekmarev/job/EDRO/4.Object/Object.php - Сборка объекта.
3.4.2. /home/chekmarev/job/EDRO/4.Object/Название объекта/ - Папка плагина.
3.4.3. /home/chekmarev/job/EDRO/4.Object/Название объекта/Название объекта.php - запускаемый файл конструирующий объект и выводящий результат в VOID.
3.4.4. /home/chekmarev/job/EDRO/4.Object/Название объекта/Class - папка с классами нужными для конструрования проекта.
3.4.5. /home/chekmarev/job/EDRO/4.Object/Название объекта/Class/Sender - формуляры собирающие данные для отправки.
3.4.6. /home/chekmarev/job/EDRO/4.Object/Название объекта/Class/Receiver - обработчики ввода для плагина


//		//$arr[] = new File($objKIIM, array(
//		//	'strDir'		=>$this->strEnterDir, 
//		//	'strName'		=>$strFile,
//		//	'bFilterDirUp'		=>$this->bIsUpperDir
//		//	));		||
					||
