<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
/*
	public $strHtml;
	
	public function __construct($a,$d)
		{
		}
	/*public function __construct($_objKiiM, $_arr('_strClass'=>'',
							'_strFunction' 	=>'',
							'_strMessage'	=>''
						))
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		
		echo 'Class='.$_arr['_strClass'].'.';
		echo 'Function='.$_arr['_strFunction'].'<br/>';
		echo 'Message='.$_arr['_strMessage'].'<br/>';
		
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		
		exit(0);
		}
	
	private function _ShowMessage($_strMessage)
		{
		print_r($this);
		echo '<Error class="block" style="color:red;">'.$_strMessage."</Error>";
		}
	public static function _Get($_objKiiM, $_arr(
					'_strClass'	=>'',
					'_strFunction' 	=>'',
					'_strMessage'	=>''
			)
			{
			$objKIIM=$_objKIIM;
			unset($_objKIIM);
			$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMetod'=>__FUNCTION__, '_strMessage'=>''));

			$objError=new	Error($objKiiM, $_arr);

			KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
			}
	}
*/
?>
