<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
//////
//$objReport = new Report($objKiiM, array(
//			'_strClass'		=>'',
//			'_strFunction' 		=>'',
//			'_strMessage'		=>'',
//			'_objBeforeCrash'	=>false,
//			));

class Report
	{
	public $strHtml;

	public function __construct($_objKIIM, $_arr)
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		echo'<fatalError class="block" style="color:#FFF;background-color:red;font-size:22px;">';
			echo 'Class	='.$_arr['_strClass'].'.';
			echo 'Function	='.$_arr['_strFunction'].'<br/>';
			echo 'Message	='.$_arr['_strMessage'].'<br/>';
		echo'</fatalError>';
		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMetod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function _ShowMessage($_strMessage)
		{
		print_r($this);
		}
	}
?>