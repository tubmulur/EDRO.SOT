<?php
//© A.A.CheckMaRev assminog@gmail.com
interface ComHTML
	{
	//public	$strHtml;
	public static function strHTML($_objKIIM, $_arr);
	}
?>
