<?php
//© A.A.CheckMaRev assminog@gmail.com
class HTML inmplements ComHTML
	{
	public	$strHtml;
	public static function strHTML($_objKIIM, $_arr);
	}
?>
