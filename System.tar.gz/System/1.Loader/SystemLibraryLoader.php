<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
////// 
   //   /\ RCe
  //  <  **> 
 //     Jl   
////// 2020
class SystemLibraryLoader
	{
	private $strName	='';
	private $strPath	='';
	private $arrLib	= array(
				'ComHTML'		=>'/home/chekmarev/Job/EDRO.SetOfTools/System/2.Interfaces/ComHTML.php',
				'Report'		=>'/home/chekmarev/Job/EDRO.SetOfTools/System/0.Reporter/Report.php',
				// 'Error'		=>'/home/chekmarev/Job/EDRO.SetOfTools/System/0.Reporter/Error.php',
				'ReportError'		=>'/home/chekmarev/Job/EDRO.SetOfTools/System/0.Reporter/ReportError.php',
				// 'Waveinspiration'	=>'/home/RCe.EDRO/4.Objects/Waveinspiration/Waveinspiration.php',
				'EDRO'			=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/EDRO.php',
				'Event'			=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/1.Event/Event.php',
				'Design'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Design.php',
				'Reality'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/3.Reality/Reality.php',

				'ReadFileSetup'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Element/ReadFileSetup.php',

				 // 'FileReality'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Reality/FileAccess.php',
				'setFilePaths'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Paths/SetFilePaths.php',
				'GetFileType'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Element/GetFileType.php',

				'ApplyTemplate'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Element/ApplyFileTemplate.php',
				'ConstructFile'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Element/ConstructFile.php',

				'ReadFileInfo'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Element/ReadFileInfo.php',


				'ConstructFileList'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/List/ConstructFileList.php',
				'ConstructFileTree'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/List/ConstructFileTree.php',
				'SortFileList'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/List/SortFileList.php',
				
				'FileStream'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Stream/FileStream.php',
				'FileWrite'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Write/FileWrite.php',

				'FileHistory'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/History/FileHistory.php',

				'FileUpload'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Upload/Upload.php',
				'FileUploadForm'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Upload/Form/UploadForm.php',
				'FileUploadDesign'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Upload/Design/UploadDesign.php',
				'FileUploadProcess'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/4.Objects/File/Upload/Process/UploadProcess.php',
				/*
				'FileAccess'		=>'/home/RCe.EDRO/4.Objects/Waveinspiration/File/FileAccess.php',
				'FileWrite'		=>'/home/RCe.EDRO/4.Objects/Waveinspiration/File/FileWrite.php',
				'FileIndex'		=>'/home/RCe.EDRO/4.Objects/Waveinspiration/File/FileIndex.php',
				'FileShow'		=>'/home/RCe.EDRO/4.Objects/Waveinspiration/File/FileShow.php',
				*/
				'HficArtistsRespect'	=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Element/HficWorkForRespect/HficWorkForRespect.php',
				'Overlay'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Element/Overlay/Overlay.php',
				'Shader'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Element/Shader/Shader.php',
				'Player'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Element/Player/Player.php',
				'DynaBlock'		=>'/home/chekmarev/Job/EDRO.SetOfTools/EDRO/2.Design/Element/DynaBlock/DynaBlock.php',
				/*
				'Constructor'		=>'/home/RCe.EDRO/4.Objects/Waveinspiration/Constructor/Constructor.php' 
				*/
			);
	public function __construct($_objKIIM)
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		foreach($this->arrLib as $strName=>$strPath)
			{
			$this->strName	=$strName;
			$this->strPath	=$strPath;
			$this->_Load($objKIIM, $strName);
			//sleep(1);
			}

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>''));
		}
	private function _Load($_objKIIM, $_strName)
		{
		$objKIIM=$_objKIIM;
		unset($_objKIIM);
		$objKIIM=KIIM::objStart($objKIIM, array('_strClass'=>__CLASS__,'_strMethod'=>__FUNCTION__, '_strMessage'=>$this->strName));
		
		require_once($this->strPath);

		KIIM::objFinish($objKIIM, array('_strClass'=>__CLASS__, '_strMethod'=>__FUNCTION__, '_strMessage'=>$this->strName));
		}
	}
?>