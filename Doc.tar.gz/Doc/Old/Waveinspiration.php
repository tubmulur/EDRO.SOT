<?php
/*© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru*/
//////   /\ RCe:b=bool;	obj=object; 	[E] Event		     E={E} arrEvent	=array('Url1', 'Url2', ...);
   //  <  **> 	str=String;int=integer;	[D] Design/Destination/ToDo  D={D} arrDesign	=array('EventTemplate1', 'EventTemplate2', ...);
 //     Jl   	arr=array;		[R] Reality/Role/Permissions R={R} arrReality	=array('EventTemplate1Dj', 'EventTemplateMc', ...);
////// 2020	_Func=return nothing	[O] Objects O={R:{E:{D}}}
/*
OBJECT predefines:
    [R]{
        'Dj'	:[D]{
		    'Tpl1':[E]{
				'Url1', 
				'Url2'
				},
		    'Tpl2':[E]{
				'Url1', 
				'Url2'
				},
		    }, 
        'MC'	:[D]{
		    'Tpl1':[E]{
				'Url1', 
				'Url2'
				},
		    'Tpl2':[E]{
				'Url1', 
				'Url2'
				},
		    }, 
        'Singer':[D]{
		    'Tpl1':[E]{
				'Url1', 
				'Url2'
				},
		    'Tpl2':[E]{
				'Url1', 
				'Url2'
				},
		    }
    } 
OBJECT constructor:
	arrEDRO=array()
class Waveinspiration
    var_predefines;
    construct:
	objEDRO=new EDRO;
	    predefines:
		Events, Designs, Realitys, Objects
	    construct:
		Event extends EDRO
			construct:
		Design extends Event
			construct:
				parent:construct;
		Reality extends Design
			construct:
				parent:construct;
		Object  extends Reality
			construct:
				parent:construct;
Waveinspiration
		->html
		->xml
		->arr
		->str
		->
		->EDRO  ->
			->
			->
			Event
			    ->
			    ->
			    ->
			    Design
				    ->
				    ->
				    ->
				    Reality
					    ->
					    ->
					    ->
					    Object

LoadLibs
	->arrLibsPath
	->
	->


Example:
Interface Waveinspiration
	constants:
	public function __construct($_objKIIM, $_arrData=array(), $strAction='default');
	public static function html($_objKIIM, $_arrData=array(), $strAction='default');
	public static function arr($_objKIIM, $_arrData=array(), $strAction='default');
	
class EDRO implements Waveinspiration
//	protected $html;
//	protected $xml;
//	protected $str;
//	protected $arr;
	

class Event extends EDRO
	{
	protected $strDir;
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		$this->strDir=$this->strGetCurrentDir();
		}
	private function strGetCurrentDir()
		{
		}
	}
class Design extends Event
	{
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		}
	}
class Reality extends Design
	{
	//What is design: design is a matrix.
	//Design classes is placed in folder /home/RCe.EDRO/2.Design/[AudioFile|Directory|TextFile|ConstructorTextForm|ConstructorAudioForm]/ClassFile.php
	//Design classes does not extends anything
	//Design classes is the matrix consists of Objects, from 4.Objects
	// Example: class DesignAudioFile 
	//			__construct()
					<audioFile>
						<audioTitleAuxDisplay>
							<aux>ObjectAudioName</aux><aux>ObjectAudioDescription</aux>
						</audioTitleAuxDisplay>
						<hficAudioWorkerRespectSystemDisplay>
							...
						</hficAudioWorkerRespectSystemDisplay>
						<playerControlsAux>
							<auxLine> <aux>ObjectRewindLeft</aux><aux>ObjectPlayButton</aux><aux>ObjectRewindRight</aux><aux></aux>	</auxLine>
							<auxLine> <aux>ObjectProgressBar</aux><aux></aux><aux></aux><aux></aux>			</auxLine>
						</playerControlsAux>
						<tagCorrectorAux>
							<auxLine> <aux>ObjInput::artist()</aux><aux>ObjInput::album()</aux><aux>ObjInput::addTagClass()</aux><aux></aux> </auxLine>
							<auxLine> <aux></aux><aux></aux><aux></aux><aux></aux> </auxLine>
						</tagCorrectorAux>
						<fileControlAux>
							<aux>ObjFileRename</aux><aux>ObjFileCompleteWithHQ</aux><aux>ObjFileCompleteWithVersions</aux><aux></aux>
							<aux>ObjFileCompleteWithRemixes</aux><aux></aux><aux></aux><aux></aux>
						</fileControlAux>
						<socialAux>
							<aux>ObjSendAudioTo::socialNet()</aux><aux>ObjSendAudioTo::myStream()</aux><aux></aux><aux></aux>
							<aux>ObjSendAudioTo::friendStream()</aux><aux></aux><aux></aux><aux></aux>
						</socialAux>
						<raitingAux>
							<aux>ObjStreamPositionGood</aux><aux>ObjStreamPositionBad</aux><aux>ObjStreamGoodLoop</aux><aux></aux>
							<aux>ObjStreamPositionMisstake</aux><aux>ObjStreamPositionClaim</aux><aux>ObjStreamClaim</aux><aux></aux>
						</raitingAux>
						<communicationAux>
							<aux></aux><aux></aux><aux></aux><aux></aux>
							<aux></aux><aux></aux><aux></aux><aux></aux>
						</communicationAux>
						<audioEventsAuxDisplay>
							<aux></aux><aux></aux><aux></aux><aux></aux>
							<aux></aux><aux></aux><aux></aux><aux></aux>
						</audioEventsAuxDisplay>
						
						
						ObjectAudioTags;
						ObjectPlayerButtonPLay;
					<audioFile>
	protected $arrHtml;
	protected $arrXml;
	protected $arrObj;
	protected $arrStr;
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		$this->arrHtml=$this->arrGetHtmlDesign();
		}
	private function arrGetHtmlDesign()
		{
		$arr['audioFile']		=DesignAudioFile::html();
		$arr['directory']		=DesignDirectory::html();
		$arr['textFile']		=DesignTextFile::html();
		$arr['formConstructorFile']	=DesignFormConstructor::html();
		$arr['audioConstructorFile']	=DesignAudioConstructor::html();
		}
	}
class File extends Reality
	{
	protected $arrLastState;
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		$this->arrLastState=$this->arrGetLastState();
		}
	private function arrGetLastState()
		{
		}
	}
class FileList extends Reality
	{
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		}
	}
class FileTree extends Reality
	{
	public function __construct($_objKIIM)
		{
		parent::__construct($_objKIIM);
		}
	}
	...
index.php:
1: loadKIIM
2: loadLoader
3: Loader->loadCore;
4: objShowFiles

*/
interface Waveinspiration
	{
	public function __construct($_objKIIM, $_arrData=array(), $_strAction='default');
	private function _Report($_objKIIM, $_arrData=array(), $_strAction='default');
	//public static function html($_objKIIM, $_arrData=array(), $strAction='default');
	//public static function arr($_objKIIM, $_arrData=array(), $strAction='default');
	}
?>