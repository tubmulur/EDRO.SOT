			<DjMix>
				<title class="block">
					<title class="block">Название микса:</title>
					<djName class="block left">DjAssminog</djName>
					<name class="block left">Weekend selection</name>
				</title>
				<audio controls>
					<source src="/music/Lubimki.Ru/DjAssminog/Lubimki.Ru_DjAssminog_Weekend.mp3"/>
				</audio>
				<Dj>
					<title class="block">Диджей<title>
					
					<publisher class="block">
						
						<header class="block">
							<title class="block left">Издательство:</title>
							<name class="block left">Любимки.РУ</name>
						</header>
						<contacts class="block">
							<email class="block"> 
								<title class="block left">Емейл:</title>
								<contactEmail class="block left">lubimki.ru@yandex.ru</contactEmail>
							</email>
							<telegram class="block">
								<title class="block left">Телеграм:</title>
								<contactPhone class="block left">+7 921 902-02-56</contactPhone>
							</telegram>
							<whatsapp class="block">
								<title class="block left">Whatsapp:</title>
								<contactPhone class="block left">+7 921 902-02-56</contactPhone>
							</whatsapp>
							<viber class="block">
								<title class="block left">Viber:</title>
								<contactPhone class="block left">--none--</contactPhone>
							</viber>
							<skype class="block">
								<title class="block left">Skype:</title>
								<contact class="block left"> -none- </contac>
							</skype>
							<icq class="block">
								<title class="block left">ICQ:</title>
								<contact class="block left">-none-</contact>
							</icq>
							<vk class="block">
								<title class="block left">VK:</title>
								<groupLink class="block left">
								    <a href="https://vk.com/radiotube" target="_blanc">radiotube</a>
								</groupLink>
							</vk>
							<facebook class="block">
								<title class="block left">Facebook:</title>
								<contact class="block left">
								<a href="https://facebook.com/radiotube" target="_blanc">radiotube</a>
								</contact>
							</facebook>
						</contacts>
						
	    				</publisher>
				</Dj>

				<tarcklist class="block">
					<track1 class="block">
						<songNumber class="block"> 
							<title class="block">Номер:</title>
							<position class="block">1</position>
							<offset>00:00:00</offset>
						</songNumber>
					</track1>
					<track2>
					</track2>
					<track3>
					</track3>
				</tarcklist>
			</DjMix>
			<!-- track>
				<label class="block">
					<header class="block">
						<title class="block left">Лейбл:</title>
						<name class="block left">Любимки.РУ</name>
					</header>
					<contacts class="block">
						<email class="block"> 
							<title class="block left">Емейл:</title>
							<contactEmail class="block left">lubimki.ru@yandex.ru</contactEmail>
						</email>
						<telegram class="block">
							<title class="block left">Телеграм:</title>
							<contactPhone class="block left">+7 921 902-02-56</contactPhone>
						</telegram>
						<whatsapp class="block">
							<title class="block left">Whatsapp:</title>
						 	
							<contactPhone class="block left">+7 921 902-02-56</contactPhone>
						</whatsapp>
						<viber class="block">
							<title class="block left">Viber:</title>
							<contactPhone class="block left">--none--</contactPhone>
						</viber>
						<skype class="block">
							<title class="block left">Skype:</title>
							<contact class="block left"> -none- </contac>
						</skype>
						<icq class="block">
							<title class="block left">ICQ:</title>
							<contact class="block left">-none-</contact>
						</icq>
						<vk class="block">
							<title class="block left">VK:</title>
							<groupLink class="block left">
								    <a href="https://vk.com/radiotube" target="_blanc">radiotube</a>
							</groupLink>
						</vk>
						<facebook class="block">
							<title class="block left">Facebook:</title>
							<contact class="block left">
								<a href="https://facebook.com/radiotube" target="_blanc">radiotube</a>
							</contact>
						</facebook>
					</contacts>
				</label>
				<autors>
					<studio>
						<technical>
						</technical>
						<instrumentPlayers>
						</instrumentPlayers>
						
					</studio>
					<compositor class="block">
						<title class="block left">Композитор:</title>
						<name>
							<title class="block left">Имя:</title>
						</name>
						<nickName>
							<title class="block left">Псевдоним:</title>
						</nickName>
						<contacts>
						</contacts>
					</compositor>
					<arranger>
						<title class="block left">Арранжировщик:</title>
						<name>
							<title class="block left">Имя:</title>
						</name>
						<nickName>
							<title class="block left">Псевдоним:</title>
						</nickName>
						<contacts>
						</contacts>
					</arranger>
				</autors>
			</track -->