<?php
© A.A.CheckMaRev assminog@gmail.com tubmulur@yandex.ru
/*
//////   /\ RCe:b=bool;	obj=object; 	[E] Event		     E={E} arrEvent	=array('Url1', 'Url2', ...);
   //  <  **> 	str=String;int=integer;	[D] Design/Destination/ToDo  D={D} arrDesign	=array('EventTemplate1', 'EventTemplate2', ...);
 //     Jl   	arr=array;		[R] Reality/Role/Permissions R={R} arrReality	=array('EventTemplate1Dj', 'EventTemplateMc', ...);
////// 2020	_Func=return nothing	[O] Objects O={R:{E:{D}}}
*/
1. Documentation: RCe.FrameWork; 
1.1. RCe.FrameWork, exists  as a philosofy of naming variables plus VectorKIM. No more tools. RCe means "Get Remote Control",  so afterlookUp your code,
    written on RCe.Framevork, you will see: Every variable that could be attacked to get RCE, looks like: $_strVariable1, $_intIntegerX, 
    $_arr('_strStrinD','_intIntegerH'). The common of this variables is "$_prexix",  while processing ypur programm as a txt file, 
    replace "$_prexix" with a filter function. So, every thing will be ok. ;





	 _______________________________		_________________________________		________________________________________
	|EDRO.Constructor		|		|EDRO.SetOfTools		|		|WWW.Project				|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|				|		|				|		|					|
	|_______________________________|		|_______________________________|		|_______________________________________|
			\						|							/
			 \						|						       /
			  \_____________________________________________|_____________________________________________________/
								       |||
								      | | |
?>